<!DOCTYPE html>
<html lang="en">
<head>
	<!-- Required meta tags -->
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">

	<!-- Koneksi Bootstrap CSS -->
	<link rel="stylesheet" href="<?= base_url('assets/css/bootstrap.min.css'); ?>">

	<title>Registrasi User | Team 10</title>
</head>

<body>
	<div class="card position-absolute top-50 start-50 translate-middle bg-light" style="width: 30rem;">
		<div class="card-body">
			<h3 class="card-title text-center">Form Registrasi User</h3>
				<?php
					if ($this->session->flashdata('error_register') !='')
					{
					 	echo "<div class='alert alert-danger' role='alert'>";
					 	echo $this->session->flashdata('error_register');
					 	echo "</div>";
					} 
				?>

				<form method="post" action="<?= site_url('daftar_user/proses_daftar/'); ?>">
					<div class="form-group">
						<label for="nama_user">Nama User</label>
						<input type="text" name="nama_user" id="nama_user" class="form-control" placeholder="Masukkan Nama User" style="margin-bottom: 10px">
					</div>
					<div class="form-group">
						<label for="username">Username</label>
						<input type="text" name="username" id="username" class="form-control" placeholder="Masukkan Username" style="margin-bottom: 10px">
					</div>
					<div class="form-group">
						<label for="password">Password</label>
						<input type="password" name="password" id="password" class="form-control" placeholder="Masukkan Password" style="margin-bottom: 10px">
					</div>
					<div class="form-group">
						<label for="id_outlet">ID_Outlet</label>
						<input type="text" name="id_outlet" id="id_outlet" class="form-control" placeholder="Masukkan ID_Outlet" style="margin-bottom: 10px">
					</div>
					<div class="form-group">
						<label for="role">Role</label>
						<select name="role" class="form-control" id="role" style="margin-bottom: 20px">
							<option value="admin">Admin</option>
							<option value="kasir">Kasir</option>
							<option value="owner">Owner</option>
						</select>
					</div>
					<button type="submit" class="btn btn-primary">Daftar</button>
				</form>
		</div>
	</div>

	<script src="<?= base_url('assets/js/bootsrtap.min.js'); ?>"></script>
	<script src="<?= base_url('assets/js/jquery.min.js'); ?>"></script>

</body>
</html>