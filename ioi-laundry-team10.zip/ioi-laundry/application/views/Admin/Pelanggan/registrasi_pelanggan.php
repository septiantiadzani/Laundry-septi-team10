	<div class="utama">
  <div class="leftside">
	<div class="container1 rounded">
    <div class="row" style="margin-bottom: 7px;">
      <div class="col">
        <h6 class="align-middle">
          <img src="<?= base_url('assets/icon/add_circle_outline_black_24dp.svg'); ?>" width="25" height="25">
          <b><i>Registrasi Pelanggan</i></b>
        </h6><!-- <hr width="34%"> -->
      </div>
    </div>
				<form method="post" action="<?= site_url('admin/proses_regist/'); ?>">
					<div class="form-group" style="margin-bottom: 15px;">
						<label for="nama_pelanggan">Nama Pelanggan</label>
						<input type="text" name="nama_pelanggan" id="nama_pelanggan" class="form-control" autocomplete="off" placeholder="Masukkan Nama Pelanggan" required>
					</div>
					<div class="form-group" style="margin-bottom: 15px;">
						<label for="alamat">Alamat</label>
						<input type="text" name="alamat" id="alamat" class="form-control" autocomplete="off" placeholder="Masukkan Alamat" required>
					</div>
					<div class="form-group" style="margin-bottom: 15px;">
						<label for="jenis_kelamin">Jenis Kelamin</label>
						<select name="jenis_kelamin" class="form-select" id="jenis_kelamin" style="cursor: pointer;" required>
							<option selected hidden disabled>-- Pilih Jenis Kelamin --</option>
							<option value="laki-laki">Laki-laki</option>
							<option value="perempuan">Perempuan</option>
						</select>
					</div>
					<div class="form-group" style="margin-bottom: 15px;">
						<label for="tlp">No. Telepon</label>
						<input type="text" name="tlp" id="tlp" class="form-control" autocomplete="off" onkeypress="return event.charCode >= 48 && event.charCode <= 57" placeholder="Masukkan Nomor Telepon" required>
					</div>
					<div class="d-flex justify-content-end">
          <div class="p-1"><button type="submit" class="btn btn-sm btn_save">Registrasi</button></div>
          <div class="p-1"><button type="reset" class="btn btn-sm btn-danger">Reset</button></div>
        </div>
			</form>
	</div>
  </div>