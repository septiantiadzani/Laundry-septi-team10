	<div class="utama">
  <div class="leftside">
    <?php if (isset($_GET['alert'])) :?>
        <?php if ($_GET['alert']=="regist_pelanggan") : ?>
          <div class="row" style="margin-left: 2.2rem;">
            <div class="col-8">
              <div class="alert alert-success alert-dismissible fade show position-fixed" role="alert">
                Proses registrasi berhasil.
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
              </div>
            </div>
          </div>
        <?php endif; ?>
        <!-- <?php if ($_GET['alert']=="edit_pelanggan") : ?>
          <div class="row" style="margin-left: 2.2rem;">
            <div class="col-8">
              <div class="alert alert-success alert-dismissible fade show position-fixed" role="alert">
                1 Data berhasil diupdate.
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
              </div>
            </div>
          </div>
        <?php endif; ?> -->
        <?php if ($_GET['alert']=="del_pelanggan") : ?>
          <div class="row" style="margin-left: 2.2rem;">
            <div class="col-8">
              <div class="alert alert-success alert-dismissible fade show position-fixed" role="alert">
                1 Data berhasil dihapus.
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
              </div>
            </div>
          </div>
        <?php endif; ?>
      <?php endif; ?>
	<div class="container1-tran rounded">
    <div class="row" style="margin-bottom: 7px;">
      <div class="col">
        <h6 class="align-middle">
          <img src="<?= base_url('assets/icon/people_black_24dp.svg'); ?>" width="25" height="25">
          <b><i>List Data Pelanggan</i></b>
        </h6><!-- <hr width="34%"> -->
      </div>
      <div class="col-4">
        <form action="<?= base_url().'admin/pelanggan/'; ?>" method="post">
          <div class="input-group input-group-sm mb-6">
            <input type="text" class="form-control" name="keyword" placeholder="Cari suatu data..." autocomplete="off" autofocus>
            <div class="input-group-append">
              <input type="submit" class="btn btn-sm btn_add" name="submit" value="Cari &telrec;">
            </div>
          </div>
        </form>
      </div>
    </div>
		<table class="table table-hover table-responsive-xl">
			<thead class="text-center" style="border-top: 1px solid black;">
				<tr class="align-middle">
					<th scope="col">No</th>
					<th scope="col">Nama Pelanggan</th>
					<th scope="col">Alamat</th>
					<th scope="col">Jenis Kelamin</th>
					<th scope="col">No. Telepon</th>
					<th scope="col">Aksi</th>
				</tr>
			</thead>
      <?php if (empty($pelanggan)) : ?>
        <tr>
          <td colspan="6">
            <div class="alert alert-danger" role="alert">
              Data tidak ditemukan!
            </div>
          </td>
        </tr>
      <?php endif; ?>
			<?php
				$count = $this->uri->segment('3') + 1;
				foreach ($pelanggan as $row) :
			?>
			<tr class="align-middle">
				<th scope="row" class="text-center"><?= $count++; ?></th>
				<td><?= $row->nama_pelanggan; ?></td>
				<td><?= $row->alamat; ?></td>
				<td class="text-center"><?= $row->jenis_kelamin; ?></td>
				<td class="text-center"><?= $row->tlp; ?></td>
				<td class="text-center">
					<!-- <a href="<?= site_url('admin/edit_pelanggan/'.$row->id_pelanggan); ?>" class="btn btn-sm btn-primary">edit</a> -->
					<a href="<?= site_url('admin/hapus_pelanggan/'.$row->id_pelanggan); ?>" class="btn btn-sm btn-outline-danger" onclick="return confirm('Apakah Anda Ingin Menghapus Data ini?')">hapus</a>
				</td>
			</tr>
		<?php endforeach; ?>
		</table>
    <div class="pagition align-middle">
      <a style="float: left;" href="<?= site_url('admin/registrasi_pelanggan'); ?>" class="btn btn-sm btn_add">
        <img src="<?= base_url('assets/icon/add_circle_outline_white_24dp.svg'); ?>" width="20" height="20">Registrasi Pelanggan</a>
      <div style="float: right;"><?= $this->pagination->create_links(); ?></div>
    </div>
	</div>
  </div>