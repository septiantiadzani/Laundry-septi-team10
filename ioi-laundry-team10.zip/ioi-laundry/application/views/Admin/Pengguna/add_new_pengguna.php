	<div class="utama">
  <div class="leftside">
	<div class="container1 rounded">
    <div class="row" style="margin-bottom: 7px;">
      <div class="col">
        <h6 class="align-middle">
          <img src="<?= base_url('assets/icon/add_circle_outline_black_24dp.svg'); ?>" width="25" height="25">
          <b><i>Tambah Pengguna</i></b>
        </h6><!-- <hr width="34%"> -->
      </div>
    </div>
			<form action="<?= site_url('admin/insert_pengguna_new'); ?>" method="post">
				<div class="form-group" style="margin-bottom: 15px">
					<label for="nama_user">Nama Pengguna</label>
					<input type="text" class="form-control" name="nama_user" id="nama_user" autocomplete="off" placeholder="Masukkan Nama Pengguna" required>
				</div>

        <div class="row">
				<div class="form-group col" style="margin-bottom: 15px">
					<label for="username">Username</label>
					<input type="text" class="form-control" name="username" id="username" autocomplete="off" placeholder="Masukkan Username" required>
				</div>
				<div class="form-group col" style="margin-bottom: 15px">
					<label for="password">Password</label>
					<input type="text" onfocus="(this.type='text')" onblur="(this.type='password')" class="form-control" name="password" id="password" autocomplete="off" placeholder="Masukkan Password" required>
				</div>
        </div>

        <div class="row">
				<div class="form-group col" style="margin-bottom: 15px">
					<label for="id_outlet">ID_Outlet</label>
          <select name="id_outlet" class="form-select" id="id_outlet" style="cursor: pointer;" required>
            <option selected disable hidden>-- Pilih ID_Outlet --</option>
            <?php foreach ($outlet->result() as $row): ?>
              <option value="<?= $row->id_outlet; ?>"><?= $row->id_outlet; ?> <?= $row->nama_outlet; ?></option>
            <?php endforeach ?>
          </select>
					<!-- <input type="text" class="form-control" name="id_outlet" id="id_outlet" onkeypress="return event.charCode >= 48 && event.charCode <= 57" placeholder="ID_Outlet" required> -->
				</div>
				<div class="form-group col" style="margin-bottom: 15px">
					<label for="role">Role</label>
					<select name="role" class="form-select" id="role" style="cursor: pointer;" required>
						<option selected disable hidden>-- Pilih Role --</option>
						<option value="admin">Admin</option>
						<option value="kasir">Kasir</option>
						<option value="owner">Owner</option>
					</select>
				</div>
        </div>

				<div class="d-flex justify-content-end">
          <div class="p-1"><button type="submit" class="btn btn-sm btn_save">Simpan</button></div>
          <div class="p-1"><button type="reset" class="btn btn-sm btn-danger">Reset</button></div>
        </div>
			</form>
	</div>
  </div>