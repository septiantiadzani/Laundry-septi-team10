<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">

	<meta name="viewport" content="width=device-width, initial-scale=1.0">

	<link rel="shortcut icon" href="<?= base_url('assets/logo-laundry2.png'); ?>">

	<title><?= $title_pdf; ?></title>

	<style type="text/css">
		#table {
			font-family: poppins;
			border-collapse: collapse;
			width: 100%;
		}

		#table td, #table th {
			border: 1px solid #ddd;
			padding: 8px;
		}

		#table tr:nth-child(even){background-color: #f2f2f2;}

		#table tr:hover {
			background-color: #ddd;
		}

		#table th {
			padding-top: 10px;
			padding-bottom: 10px;
			text-align: left;
			background-color: #4caf50;
			color: white;
		}
	</style>
</head>
<body>
	<div style="text-align: center;">
		<h3>Report Data Member</h3>
	</div>
	<table id="table">
		<thead>
			<tr>
				<th>No.</th>
				<th>Id Transaksi</th>
				<th>Tanggal</th>
				<th>Jumlah Transaksi</th>
				<th>Total Hasil</th>
				<th>ID Pengguna</th>
			</tr>
		</thead>
		<tbody>
			<?php
				$no = 1;
				foreach ($laporan as $l) {
			?>
			<tr>
				<td scope="row"><?= $no++; ?></td>
				<td><?= $l->id_transaksi; ?></td>
				<td><?= $l->tgl; ?></td>
				<td><?= $l->jumlah_transaksi; ?></td>
				<td><?= $l->total_hasil; ?></td>
				<td><?= $l->id_user; ?></td>
			</tr>
		<?php } ?>
		</tbody>
	</table>
</body>
</html>