	<div class="utama">
	<div class="leftside">
	<div class="container1 rounded">
	<div class="row" style="margin-bottom: 7px;">
      <div class="col">
        <h6 class="align-middle">
          <img src="<?= base_url('assets/icon/receipt_long_black_24dp.svg'); ?>" width="25" height="25">
          <b><i>List Data Laporan</i></b>
        </h6><!-- <hr width="34%"> -->
      </div>
    </div>
		<!-- <table class="table table-hover">
			<thead class="text-center">
				<tr class="align-middle">
					<th scope="col">No</th>
					<th scope="col">ID_Transaksi</th>
					<th scope="col">Tanggal</th>
					<th scope="col">Jumlah Transaksi</th>
					<th scope="col">Total Hasil</th>
					<th scope="col">ID_Pengguna</th>
					<th scope="col">Aksi</th>
				</tr>
			</thead>
			<?php
				$count = 0;
				foreach ($laporan->result() as $row) :
					$count++;
			?>
			<tr class="align-middle">
				<th scope="row" class="text-center"><?= $count; ?></th>
				<td class="text-center"><?= $row->id_transaksi; ?></td>
				<td class="text-center"><?= $row->tgl; ?></td>
				<td class="text-center"><?= $row->jumlah_transaksi; ?></td>
				<td class="text-center"><?= $row->total_hasil; ?></td>
				<td class="text-center"><?= $row->id_user; ?></td>
				<td class="text-center">
					<a href="<?= site_url('admin/edit_transaksi/'.$row->id_transaksi); ?>" class="btn btn-sm btn-primary">edit</a>
					<a target="_blank" href="<?= site_url('admin/pdfview_laporan/'); ?>" class="btn btn-sm btn-primary">view</a>
					<a href="<?= site_url('admin/hapus_laporan/'.$row->id_laporan); ?>" class="btn btn-sm btn-danger">hapus</a>
				</td>
			</tr>
		<?php endforeach; ?>
		</table> -->
		<!-- <a href="<?= site_url('admin/add_laporan_new'); ?>" class="btn btn-sm btn_add">Tambah Laporan</a> -->
	</div>
	</div>