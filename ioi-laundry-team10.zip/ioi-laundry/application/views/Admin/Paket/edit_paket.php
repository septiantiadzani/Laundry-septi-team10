	<div class="utama">
  <div class="leftside">
	<div class="container1 rounded">
    <div class="row" style="margin-bottom: 7px;">
      <div class="col">
        <h6 class="align-middle">
          <img src="<?= base_url('assets/icon/edit_black_24dp.svg'); ?>" width="25" height="25">
          <b><i>Edit Paket Cucian</i></b>
        </h6><!-- <hr width="34%"> -->
      </div>
    </div>
			<form action="<?= site_url('admin/update_paket'); ?>" method="post">
				<div class="form-group" style="margin-bottom: 15px">
					<label for="id_outlet">ID_Outlet</label>
          <select name="id_outlet" class="form-select" id="id_outlet" style="cursor: pointer;" required>
            <option selected disable hidden><?= $id_outlet; ?></option>
            <?php foreach ($outlet->result() as $row): ?>
              <option value="<?= $row->id_outlet; ?>"><?= $row->id_outlet; ?> <?= $row->nama_outlet; ?></option>
            <?php endforeach ?>
          </select>
					<!-- <input type="text" class="form-control" name="id_outlet" id="id_outlet" onkeypress="return event.charCode >= 48 && event.charCode <= 57" value="<?= $id_outlet; ?>" placeholder="ID_Outlet" required> -->
				</div>
				<div class="form-group" style="margin-bottom: 15px">
					<label for="nama_paket">Nama Paket</label>
					<input type="text" class="form-control" name="nama_paket" id="nama_paket" value="<?= $nama_paket; ?>" placeholder="Masukkan Nama Paket" autocomplete="off" required>
				</div>
				<div class="form-group" style="margin-bottom: 15px">
					<label for="jenis_paket">Jenis Paket</label>
					<select name="jenis_paket" class="form-select" id="jenis_paket" style="cursor: pointer;">
						<option selected disable hidden><?= $jenis_paket; ?></option>
						<option value="kiloan">Kiloan</option>
						<option value="selimut">Selimut</option>
						<option value="bed_cover">Bed Cover</option>
						<option value="kaos">Kaos</option>
						<option value="lain">Lainnya</option>
					</select>
				</div>
				<div class="form-group" style="margin-bottom: 15px">
					<label for="harga_paket">Harga</label>
					<input type="text" class="form-control" name="harga_paket" id="harga_paket" onkeypress="return event.charCode >= 48 && event.charCode <= 57" value="<?= $harga_paket; ?>" placeholder="Masukkan Harga Paket" autocomplete="off" required>
				</div>
				<input type="hidden" name="id_paket" value="<?= $id_paket; ?>">
				<div class="d-flex justify-content-end">
					<div class="p-1"><button type="submit" class="btn btn-sm btn_save">Simpan Perubahan</button></div>
					<div class="p-1"><button type="reset" class="btn btn-sm btn-danger">Reset</button></div>
				</div>
			</form>
	</div>
  </div>