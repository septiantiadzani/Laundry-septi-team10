	<div class="utama">
  <div class="leftside">
	<div class="container1 rounded">
    <div class="row" style="margin-bottom: 7px;">
      <div class="col">
        <h6 class="align-middle">
          <img src="<?= base_url('assets/icon/add_circle_outline_black_24dp.svg'); ?>" width="25" height="25">
          <b><i>Tambah Outlet</i></b>
        </h6><!-- <hr width="34%"> -->
      </div>
    </div>
			<form action="<?= site_url('admin/insert_outlet_new'); ?>" method="post">
				<div class="form-group" style="margin-bottom: 15px">
					<label for="nama_outlet">Nama Outlet</label>
					<input type="text" class="form-control" name="nama_outlet" id="nama_outlet" autocomplete="off" placeholder="Masukkan Nama Outlet" required>
				</div>
				<div class="form-group" style="margin-bottom: 15px">
					<label for="alamat">Alamat</label>
					<input type="text" class="form-control" name="alamat" id="alamat" autocomplete="off" placeholder="Masukkan Alamat Outlet" required>
				</div>
				<div class="form-group" style="margin-bottom: 15px">
					<label for="tlp">No. Telepon</label>
					<input type="text" class="form-control" name="tlp" id="tlp" autocomplete="off" onkeypress="return event.charCode >= 48 && event.charCode <= 57" placeholder="Masukkan Nomor Telepon" required>
				</div>
				<div class="d-flex justify-content-end">
          <div class="p-1"><button type="submit" class="btn btn-sm btn_save">Simpan</button></div>
          <div class="p-1"><button type="reset" class="btn btn-sm btn-danger">Reset</button></div>
        </div>
			</form>
	</div>
  </div>