	<div class="utama">
  <div class="leftside">
	<div class="container1 rounded">
    <div class="row" style="margin-bottom: 7px;">
      <div class="col">
        <h6 class="align-middle">
          <img src="<?= base_url('assets/icon/paid_black_24dp.svg'); ?>" width="25" height="25">
          <b><i>Detail Transaksi</i></b>
        </h6><!-- <hr width="34%"> -->
      </div>
    </div>
			<form action="<?= site_url('admin/update_transaksi/'); ?>" method="post">
        <div class="row">
				<div class="form-group col" style="margin-bottom: 15px">
					<label for="id_outlet">ID_Outlet</label>
          <input type="text" value="<?= $id_outlet; ?>" class="form-control" name="id_outlet" id="id_outlet" placeholder="Masukkan ID_Outlet" readonly>
          <!-- <select name="id_outlet" class="form-select" id="id_outlet" style="cursor: pointer;" required>
            <option selected disable hidden><?= $id_outlet; ?></option>
            <?php foreach ($outlet->result() as $row): ?>
              <option value="<?= $row->id_outlet; ?>"><?= $row->id_outlet; ?> <?= $row->nama_outlet; ?></option>
            <?php endforeach ?>
          </select> -->
					<!-- <input type="text" class="form-control" name="nama_outlet" id="nama_outlet" placeholder="Nama Outlet" required> -->
				</div>
				<div class="form-group col" style="margin-bottom: 15px">
					<label for="kode_invoice">Kode Invoice</label>
					<input type="text" class="form-control" name="kode_invoice" id="kode_invoice" value="<?= $kode_invoice; ?>" placeholder="Masukkan Kode Invoice" readonly>
				</div>
				<div class="form-group col" style="margin-bottom: 15px">
					<label for="id_pelanggan">ID_Pelanggan</label>
          <input type="text" value="<?= $id_pelanggan; ?>" class="form-control" name="id_pelanggan" id="id_pelanggan" placeholder="Masukkan ID_Pelanggan" readonly>
          <!-- <select name="id_pelanggan" class="form-select" id="id_pelanggan" style="cursor: pointer;" required>
            <option selected disable hidden><?= $id_pelanggan; ?></option>
            <?php foreach ($pelanggan->result() as $row): ?>
              <option value="<?= $row->id_pelanggan; ?>"><?= $row->id_pelanggan; ?> <?= $row->nama_pelanggan; ?></option>
            <?php endforeach ?>
          </select> -->
					<!-- <input type="text" class="form-control" name="id_pelanggan" id="id_pelanggan" onkeypress="return event.charCode >= 48 && event.charCode <= 57" placeholder="No. Telepon" required> -->
				</div>
        </div>

        <div class="row">
          <div class="form-group col" style="margin-bottom: 15px">
            <label for="tgl">Tanggal</label>
            <input type="text" value="<?= $tgl; ?>" class="form-control" name="tgl" id="tgl" placeholder="Masukkan Tanggal" readonly>
          </div>
          <div class="form-group col" style="margin-bottom: 15px">
            <label for="batas_waktu">Batas Waktu</label>
            <input type="text" value="<?= $batas_waktu; ?>" class="form-control" name="batas_waktu" id="batas_waktu" placeholder="Masukkan Batas Waktu" readonly>
          </div>
          <div class="form-group col" style="margin-bottom: 15px">
            <label for="tgl_bayar">Tanggal Bayar</label>
            <input type="text" onfocus="(this.type='datetime-local')" onblur="(this.type='text')" value="<?= $tgl_bayar; ?>" class="form-control" name="tgl_bayar" id="tgl_bayar" placeholder="Masukkan Tanggal Bayar">
          </div>
        </div>

        <div class="row">
          <div class="form-group col" style="margin-bottom: 15px">
            <label for="nama_paket">Nama Paket</label>
            <input type="text" value="" class="form-control" name="nama_paket" id="nama_paket" placeholder="Masukkan Nama Paket" readonly>
            <!-- <select name="jenis_paket" class="form-select" id="jenis_paket" style="cursor: pointer;" required>
            <option selected disable hidden>-- Pilih Paket --</option>
            <?php foreach ($paket->result() as $row): ?>
              <option value="<?= $row->id_paket; ?>"><?= $row->nama_paket; ?></option>
            <?php endforeach ?>
            </select> -->
          </div>
          <div class="form-group col" style="margin-bottom: 15px">
            <label for="harga">Harga</label>
            <input type="text" class="form-control" name="harga" id="harga" autocomplete="off" onkeypress="return event.charCode >= 48 && event.charCode <= 57" placeholder="Harga" required readonly>
          </div>
          <div class="form-group col" style="margin-bottom: 15px">
            <label for="berat">Berat</label>
            <input type="text" value="<?= $berat; ?>" class="form-control" name="berat" id="berat" autocomplete="off" onkeypress="return event.charCode >= 48 && event.charCode <= 57" placeholder="Masukkan Berat Kg" required readonly>
          </div>
          <div class="form-group col" style="margin-bottom: 15px">
            <label for="grand_total">Grand Total</label>
            <input type="text" value="<?= $grand_total; ?>" class="form-control" name="grand_total" id="grand_total" autocomplete="off" onkeypress="return event.charCode >= 48 && event.charCode <= 57" placeholder="Grand Total" required readonly>
          </div>
        </div>

        <!-- <div class="row">
          <div class="form-group col" style="margin-bottom: 15px">
            <label for="jumlah_cucian">Jumlah Cucian</label>
            <input type="text" class="form-control" name="jumlah_cucian" id="jumlah_cucian" value="<?= $jumlah_cucian; ?>" onkeypress="return event.charCode >= 48 && event.charCode <= 57" placeholder="Masukkan Jumlah Cucian" readonly>
          </div>
            <div class="form-group col" style="margin-bottom: 15px">
            <label for="biaya_tambahan">Biaya Tambahan</label>
            <input type="text" class="form-control" name="biaya_tambahan" id="biaya_tambahan" value="<?= $biaya_tambahan; ?>" onkeypress="return event.charCode >= 48 && event.charCode <= 57" placeholder="Masukkan Biaya Tambahan" readonly>
          </div>
          <div class="form-group col" style="margin-bottom: 15px">
            <label for="diskon">Diskon</label>
            <input type="text" class="form-control" name="diskon" id="diskon" value="<?= $diskon; ?>" onkeypress="return event.charCode >= 48 && event.charCode <= 57" placeholder="Masukkan Diskon" readonly>
          </div>
          <div class="form-group col" style="margin-bottom: 15px">
            <label for="pajak">Pajak</label>
            <input type="text" class="form-control" name="pajak" id="pajak" value="<?= $pajak; ?>" onkeypress="return event.charCode >= 48 && event.charCode <= 57" placeholder="Masukkan Pajak" readonly>
          </div>
        </div> -->

        <div class="row">
          <div class="form-group col" style="margin-bottom: 15px">
            <label for="status">Status</label>
              <select name="status" class="form-select" id="status" style="cursor: pointer;">
                <option selected disable hidden><?= $status; ?></option>
                <option value="baru">Baru</option>
                <option value="proses">Proses</option>
                <option value="selesai">Selesai</option>
                <option value="diambil">Diambil</option>
              </select>
          </div>
          <div class="form-group col" style="margin-bottom: 15px">
            <label for="dibayar">Dibayar</label>
              <select name="dibayar" class="form-select" id="dibayar" style="cursor: pointer;">
                <option selected disable hidden><?= $dibayar; ?></option>
                <option value="telah_dibayar">Telah Dibayar</option>
                <option value="belum_dibayar">Belum Dibayar</option>
              </select>
          </div>
          <div class="form-group col" style="margin-bottom: 15px">
            <label for="id_user">ID_User</label>
            <input type="text" value="<?= $id_user; ?>" class="form-control" name="id_user" id="id_user" placeholder="Masukkan ID_User" readonly>
            <!-- <select name="id_user" class="form-select" id="id_user" style="cursor: pointer;">
              <option selected disable hidden><?= $id_user; ?></option>
              <?php foreach ($pengguna->result() as $row): ?>
                <option value="<?= $row->id_user; ?>"><?= $row->id_user; ?> <?= $row->nama_user; ?> - <?= $row->role; ?></option>
              <?php endforeach ?>
            </select> -->
          </div>
        </div>
        <input type="hidden" name="id_transaksi" value="<?= $id_transaksi; ?>">

				<div class="d-flex justify-content-end">
          <div class="p-1"><button type="submit" class="btn btn-sm btn_save">Simpan Perubahan</button></div>
          <div class="p-1"><button hidden type="submit" class="btn btn-sm btn-danger">Cetak Invoice</button></div>
          <div class="p-1"><button type="reset" class="btn btn-sm btn-danger">Reset</button></div>
        </div>
			</form>
      <!-- <br>
      <table class="table table-hover">
      <thead class="text-center">
        <tr class="align-middle">
          <th scope="col">No</th>
          <th scope="col">Tanggal</th>
        </tr>
      </thead>
      <?php
        $count = 0;
        foreach ($join as $row) :
      ?>
      <tr class="align-middle">
        <th scope="row" class="text-center"><?= $count++; ?></th>
        <td class="text-center"><?= $row->tgl; ?></td>
      </tr>
    <?php endforeach; ?>
    </table> -->
	</div>
  </div>