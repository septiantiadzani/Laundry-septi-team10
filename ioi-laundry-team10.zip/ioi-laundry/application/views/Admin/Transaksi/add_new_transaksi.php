	<div class="utama">
  <div class="leftside">
	<div class="container1 rounded">
    <div class="row" style="margin-bottom: 7px;">
      <div class="col">
        <h6 class="align-middle">
          <img src="<?= base_url('assets/icon/paid_black_24dp.svg'); ?>" width="25" height="25">
          <b><i>Tambah Entri Transaksi</i></b>
        </h6><!-- <hr width="34%"> -->
      </div>
    </div>
			<form action="<?= site_url('admin/insert_transaksi_new'); ?>" method="post">
        <div class="row">
				<div class="form-group col" style="margin-bottom: 15px">
					<label for="id_outlet">ID_Outlet</label>
          <select name="id_outlet" class="form-select" id="id_outlet" style="cursor: pointer;" required>
            <option selected disable hidden>-- Pilih ID_Outlet --</option>
            <?php foreach ($outlet->result() as $row): ?>
              <option value="<?= $row->id_outlet; ?>"><?= $row->id_outlet; ?> <?= $row->nama_outlet; ?></option>
            <?php endforeach ?>
          </select>
					<!-- <input type="text" class="form-control" name="nama_outlet" id="nama_outlet" placeholder="Nama Outlet" required> -->
				</div>
				<div class="form-group col" style="margin-bottom: 15px">
					<label for="kode_invoice">Kode Invoice</label>
					<input type="text" class="form-control" name="kode_invoice" id="kode_invoice" placeholder="Masukkan Kode Invoice" required>
				</div>
				<div class="form-group col" style="margin-bottom: 15px">
					<label for="id_pelanggan">ID_Pelanggan</label>
          <select name="id_pelanggan" class="form-select" id="id_pelanggan" style="cursor: pointer;" required>
            <option selected disable hidden>-- Pilih ID_Pelanggan --</option>
            <?php foreach ($pelanggan->result() as $row): ?>
              <option value="<?= $row->id_pelanggan; ?>"><?= $row->id_pelanggan; ?> <?= $row->nama_pelanggan; ?></option>
            <?php endforeach ?>
          </select>
					<!-- <input type="text" class="form-control" name="id_pelanggan" id="id_pelanggan" onkeypress="return event.charCode >= 48 && event.charCode <= 57" placeholder="No. Telepon" required> -->
				</div>
        </div>

        <div class="row">
          <div class="form-group col" style="margin-bottom: 15px">
            <label for="tgl">Tanggal</label>
            <input type="datetime-local" class="form-control" name="tgl" id="tgl" placeholder="Masukkan Tanggal" required>
          </div>
            <div class="form-group col" style="margin-bottom: 15px">
            <label for="batas_waktu">Batas Waktu</label>
            <input type="datetime-local" class="form-control" name="batas_waktu" id="batas_waktu" placeholder="Masukkan Batas Waktu" required>
          </div>
          <div class="form-group col" style="margin-bottom: 15px">
            <label for="tgl_bayar">Tanggal Bayar</label>
            <input type="datetime-local" class="form-control" name="tgl_bayar" id="tgl_bayar" placeholder="Masukkan Tanggal Bayar">
          </div>
        </div>

        <div class="row">
          <div class="form-group col" style="margin-bottom: 15px">
            <label for="jenis_paket">Nama Paket</label>
            <select name="jenis_paket" class="form-select" id="jenis_paket" style="cursor: pointer;" required>
            <option selected disable hidden>-- Pilih Paket --</option>
            <?php foreach ($paket->result() as $row): ?>
              <option value="<?= $row->id_paket; ?>"><?= $row->nama_paket; ?></option>
            <?php endforeach ?>
            </select>
          </div>
          <div class="form-group col" style="margin-bottom: 15px">
            <label for="harga">Harga</label>
            <input type="text" class="form-control" name="harga" id="harga" autocomplete="off" onkeypress="return event.charCode >= 48 && event.charCode <= 57" placeholder="Harga" required readonly>
          </div>
          <div class="form-group col" style="margin-bottom: 15px">
            <label for="berat">Berat</label>
            <input type="text" class="form-control" name="berat" id="berat" autocomplete="off" onkeypress="return event.charCode >= 48 && event.charCode <= 57" placeholder="Masukkan Berat Kg" required>
          </div>
          <div class="form-group col" style="margin-bottom: 15px">
            <label for="grand_total">Grand Total</label>
            <input type="text" class="form-control" name="grand_total" id="grand_total" autocomplete="off" onkeypress="return event.charCode >= 48 && event.charCode <= 57" placeholder="Grand Total" required readonly>
          </div>
        </div>

        <!-- <div class="row">
          <div class="form-group col" style="margin-bottom: 15px">
            <label for="biaya_tambahan">Biaya Tambahan</label>
            <input type="text" class="form-control" name="biaya_tambahan" id="biaya_tambahan" autocomplete="off" onkeypress="return event.charCode >= 48 && event.charCode <= 57" placeholder="Masukkan Biaya Tambahan" required>
          </div>
          <div class="form-group col" style="margin-bottom: 15px">
            <label for="diskon">Diskon</label>
            <input type="text" class="form-control" name="diskon" id="diskon" autocomplete="off" onkeypress="return event.charCode >= 48 && event.charCode <= 57" placeholder="Masukkan Diskon" required>
          </div>
          <div class="form-group col" style="margin-bottom: 15px">
            <label for="pajak">Pajak</label>
            <input type="text" class="form-control" name="pajak" id="pajak" autocomplete="off" onkeypress="return event.charCode >= 48 && event.charCode <= 57" placeholder="Masukkan Pajak" required>
          </div>
        </div> -->

        <div class="row">
          <div class="form-group col" style="margin-bottom: 15px">
            <label for="status">Status</label>
              <select name="status" class="form-select" id="status" style="cursor: pointer;" required>
                <option selected disable hidden>-- Pilih Status --</option>
                <option value="baru">Baru</option>
                <option value="proses">Proses</option>
                <option value="selesai">Selesai</option>
                <option value="diambil">Diambil</option>
              </select>
          </div>
          <div class="form-group col" style="margin-bottom: 15px">
            <label for="dibayar">Dibayar</label>
              <select name="dibayar" class="form-select" id="dibayar" style="cursor: pointer;" required>
                <option selected disable hidden>-- Pilih --</option>
                <option value="telah_dibayar">Telah Dibayar</option>
                <option value="belum_dibayar">Belum Dibayar</option>
              </select>
          </div>
          <div class="form-group col" style="margin-bottom: 15px">
            <label for="id_user">ID_User</label>
            <select name="id_user" class="form-select" id="id_user" style="cursor: pointer;" required>
            <option selected disable hidden>-- Pilih ID_User --</option>
            <?php foreach ($pengguna->result() as $row): ?>
              <option value="<?= $row->id_user; ?>"><?= $row->id_user; ?> <?= $row->nama_user; ?> - <?= $row->role; ?></option>
            <?php endforeach ?>
          </select>
          </div>
        </div>

				<div class="d-flex justify-content-end">
          <div class="p-1"><button type="submit" class="btn btn-sm btn_save">Tambah</button></div>
          <div class="p-1"><button type="reset" class="btn btn-sm btn-danger">Reset</button></div>
        </div>
			</form>
	</div>
  </div>