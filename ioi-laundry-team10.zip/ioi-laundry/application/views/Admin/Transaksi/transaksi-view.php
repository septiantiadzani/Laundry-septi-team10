	<div class="utama">
  <div class="leftside">
    <?php if (isset($_GET['alert'])) :?>
        <?php if ($_GET['alert']=="add_transaksi") : ?>
          <div class="row" style="margin-left: 2.2rem;">
            <div class="col-8">
              <div class="alert alert-success alert-dismissible fade show position-fixed" role="alert">
                Transaksi baru berhasil ditambahkan.
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
              </div>
            </div>
          </div>
        <?php endif; ?>
        <!-- <?php if ($_GET['alert']=="edit_transaksi") : ?>
          <div class="row" style="margin-left: 2.2rem;">
            <div class="col-8">
              <div class="alert alert-success alert-dismissible fade show position-fixed" role="alert">
                1 Data berhasil diupdate.
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
              </div>
            </div>
          </div>
        <?php endif; ?>
        <?php if ($_GET['alert']=="del_transaksi") : ?>
          <div class="row" style="margin-left: 2.2rem;">
            <div class="col-8">
              <div class="alert alert-success alert-dismissible fade show position-fixed" role="alert">
                1 Data berhasil dihapus.
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
              </div>
            </div>
          </div>
        <?php endif; ?> -->
      <?php endif; ?>
	<div class="container1-tran rounded">
    <div class="row" style="margin-bottom: 7px;">
      <div class="col">
        <h6 class="align-middle">
          <img src="<?= base_url('assets/icon/paid_black_24dp.svg'); ?>" width="25" height="25">
          <b><i>List Data Transaksi</i></b>
        </h6><!-- <hr width="34%"> -->
      </div>
      <div class="col-4">
        <form action="<?= base_url().'admin/transaksi/'; ?>" method="post">
          <div class="input-group input-group-sm mb-6">
            <input type="text" class="form-control" name="keyword" placeholder="Cari suatu data..." autocomplete="off" autofocus>
            <div class="input-group-append">
              <input type="submit" class="btn btn-sm btn_add" name="submit" value="Cari &telrec;">
            </div>
          </div>
        </form>
      </div>
    </div>
		<table class="table table-hover table-responsive-xl">
			<thead class="text-center" style="border-top: 1px solid black">
				<tr class="align-middle">
					<th scope="col">No</th>
					<th scope="col">ID_Pelanggan</th>
					<th scope="col">Tanggal</th>
					<th scope="col">Batas Waktu</th>
					<th scope="col">Tanggal Bayar</th>
					<th scope="col">Status</th>
					<th scope="col">Dibayar</th>
					<th scope="col">ID_User</th>
					<th scope="col">Aksi</th>
				</tr>
			</thead>
      <?php if (empty($transaksi)) : ?>
        <tr>
          <td colspan="9">
            <div class="alert alert-danger" role="alert">
              Data tidak ditemukan!
            </div>
          </td>
        </tr>
      <?php endif; ?>
			<?php
				$count = $this->uri->segment('3') + 1;
				foreach ($transaksi as $row) :
			?>
			<tr class="align-middle">
				<th scope="row" class="text-center"><?= $count++; ?></th>
				<td class="text-center"><?= $row->id_pelanggan; ?></td>
				<td class="text-center"><?= $row->tgl; ?></td>
				<td class="text-center"><?= $row->batas_waktu; ?></td>
				<td class="text-center"><?= $row->tgl_bayar; ?></td>
				<td class="text-center"><button class="btn btn-light btn-sm"><?= $row->status; ?></button></td>
				<td class="text-center"><button class="btn btn-success btn-sm"><?= $row->dibayar; ?></button></td>
				<td class="text-center"><?= $row->id_user; ?></td>
				<td class="text-center">
          <a href="<?= site_url('admin/detail_transaksi/'.$row->id_transaksi); ?>" class="btn btn-sm btn-outline-primary">detail</a>
					<!-- <a href="<?= site_url('admin/edit_transaksi/'.$row->id_transaksi); ?>" class="btn btn-sm btn-primary">edit</a>
					<a href="<?= site_url('admin/hapus_transaksi/'.$row->id_transaksi); ?>" class="btn btn-sm btn-danger">hapus</a> -->
				</td>
			</tr>
		<?php endforeach; ?>
		</table>
    <div class="pagition align-middle">
      <a style="float: left;" href="<?= site_url('admin/add_transaksi_new'); ?>" class="btn btn-sm btn_add">
        <img src="<?= base_url('assets/icon/add_circle_outline_white_24dp.svg'); ?>" width="20" height="20">Tambah Transaksi
      </a>
      <div style="float: right;"><?= $this->pagination->create_links(); ?></div>
    </div>
	</div>
  </div>