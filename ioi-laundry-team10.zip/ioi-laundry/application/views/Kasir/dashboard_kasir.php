	<div class="utama">
  <div class="leftside">
    <?php if (isset($_GET['alert'])) :?>
        <?php if ($_GET['alert']=="welcome_kasir") : ?>
          <div class="row" style="margin-left: 2.2rem;">
            <div class="col-8">
              <div class="alert alert-success alert-dismissible fade show position-fixed" role="alert">
                Selamat datang kasir <strong><?= $this->session->userdata('nama_user'); ?></strong> di aplikasi IOI Laundry.
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
              </div>
            </div>
          </div>
        <?php endif; ?>
      <?php endif; ?>
	<div class="container1-tran rounded">
    <div class="row" style="margin-bottom: 7px;">
      <div class="col">
        <h6 class="align-middle">
          <img src="<?= base_url('assets/icon/paid_black_24dp.svg'); ?>" width="25" height="25">
          <b><i>List Data Transaksi Baru</i></b>
        </h6><!-- <hr width="34%"> -->
      </div>
      <div class="col-4">
        <form action="<?= base_url().'kasir/index/'; ?>" method="post">
          <div class="input-group input-group-sm mb-6">
            <input type="text" class="form-control" name="keyword" placeholder="Cari suatu data..." autocomplete="off" autofocus>
            <div class="input-group-append">
              <input type="submit" class="btn btn-sm btn_add" name="submit" value="Cari &telrec;">
            </div>
          </div>
        </form>
      </div>
    </div>
    <table class="table table-hover table-responsive-xl">
      <thead class="text-center" style="border-top: 1px solid black;">
        <tr class="align-middle">
          <th scope="col">No</th>
          <th scope="col">ID_Pelanggan</th>
          <th scope="col">Tanggal</th>
          <th scope="col">Batas Waktu</th>
          <th scope="col">Berat</th>
          <th scope="col">Grand Total</th>
          <th scope="col">Status</th>
          <th scope="col">Dibayar</th>
          <!-- <th scope="col">ID_User</th> -->
        </tr>
      </thead>
      <?php if (empty($transaksi)) : ?>
        <tr>
          <td colspan="8">
            <div class="alert alert-danger" role="alert">
              Data tidak ditemukan!
            </div>
          </td>
        </tr>
      <?php endif; ?>
      <?php
        $count = $this->uri->segment('3') + 1;
        foreach ($transaksi as $row) :
      ?>
      <tr class="align-middle">
        <th scope="row" class="text-center"><?= $count++; ?></th>
        <td class="text-center"><?= $row->id_pelanggan; ?></td>
        <td class="text-center"><?= $row->tgl; ?></td>
        <td class="text-center"><?= $row->batas_waktu; ?></td>
        <td class="text-center"><?= $row->berat; ?></td>
        <td class="text-center"><?= $row->grand_total; ?></td>
        <td class="text-center"><button class="btn btn-light btn-sm"><?= $row->status; ?></button></td>
        <td class="text-center"><button class="btn btn-success btn-sm"><?= $row->dibayar; ?></button></td>
        <!-- <td class="text-center"><?= $row->id_user; ?></td> -->
      </tr>
    <?php endforeach; ?>
    </table>
    <div class="pagition align-middle">
      <div style="float: right;"><?= $this->pagination->create_links(); ?></div>
    </div>
    <!-- <table class="table table-hover table-responsive-xl">
      <thead class="text-center" style="border-top: 1px solid black;">
        <tr class="align-middle">
          <th scope="col">No</th>
          <th scope="col">ID_Pelanggan</th>
          <th scope="col">Tanggal</th>
          <th scope="col">Tanggal Bayar</th>
          <th scope="col">Jumlah Cucian</th>
          <th scope="col">Status</th>
          <th scope="col">Dibayar</th>
          <th scope="col">ID_User</th>
        </tr>
      </thead>
      <?php if (empty($transaksi)) : ?>
        <tr>
          <td colspan="8">
            <div class="alert alert-danger" role="alert">
              Data tidak ditemukan!
            </div>
          </td>
        </tr>
      <?php endif; ?>
      <?php
        $count = $this->uri->segment('3') + 1;
        foreach ($transaksi as $row) :
      ?>
      <tr class="align-middle">
        <th scope="row" class="text-center"><?= $count++; ?></th>
        <td class="text-center"><?= $row->id_pelanggan; ?></td>
        <td class="text-center"><?= $row->tgl; ?></td>
        <td class="text-center"><?= $row->tgl_bayar; ?></td>
        <td class="text-center"><?= $row->jumlah_cucian; ?></td>
        <td class="text-center"><button class="btn btn-light btn-sm"><?= $row->status; ?></button></td>
        <td class="text-center"><button class="btn btn-success btn-sm"><?= $row->dibayar; ?></button></td>
        <td class="text-center"><?= $row->id_user; ?></td>
      </tr>
    <?php endforeach; ?>
    </table>
    <div class="pagition align-middle">
      <div style="float: right;"><?= $this->pagination->create_links(); ?></div>
    </div> -->
	</div>
  </div>