<!DOCTYPE html>
<html lang="en">
<head>
	<!-- Required meta tags -->
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">

	<!-- Koneksi Bootstrap CSS -->
	<link rel="stylesheet" href="<?= base_url('assets/css/bootstrap.min.css'); ?>" !important>

  <link rel="stylesheet" type="text/css" href="<?= base_url('assets/css/mycss/for_all.css'); ?>">

	<title>Example Dashboard</title>

</head>
<body> <!-- class="bg-secondary" -->
		<nav class="navbar navbar-expand-lg sticky-top navbarlight">
        <a class="navbar-brand" href="#">
          <img src="<?= base_url('assets/website.svg'); ?>" width="40" height="40">
        </a>
        <!-- <button class="navbar-toggle" type="button" data-toggle="collapse" data-target="#navbarNavAltMarkup"
        aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggle-icon"></span>
        </button> -->
  			<div class="collapse navbar-collapse" id="navbarNavAltMarkup">
    		<ul class="navbar-nav">
      			<li class="nav-item active"> <a href="#" class="nav-link">Dashboard</a> </li>
      			<li class="nav-item dropdown">
              <a href="#" class="nav-link dropdown-toggle" id="navbarDropdown" role="button" data-toggle="dropdown"
              aria-haspopup="true" aria-expanded="false">Data Khusus</a>
              <div class="dropdown-menu" aria-lebelledby="navbarDropdown">
                <a href="#" class="dropdown-item">Data Paket</a>
                <a href="#" class="dropdown-item">Data Outlet</a>
                <a href="#" class="dropdown-item">Data Pengguna</a>
                <div class="dropdown-divider"></div>
                <a href="#" class="dropdown-item">Data Pelanggan</a>
              </div>
            </li>
				    <li class="nav-item"> <a href="#" class="nav-link">Data Transaksi</a> </li>
				    <li class="nav-item"> <a href="#" class="nav-link">Data Laporan</a> </li>
    		</ul>
  			</div>
        <div class="profile">
          <div class="ikon">
            <a href="<?= base_url().'login2'; ?>" class="btn btn-primary">Login</a>
          </div>
          <div class="text">
            <div class="text1">
              salm
            </div>
            <div class="text2">uhsuw</div>
          </div>
        </div>
        <div class="out"><button class="btn-danger">logout</button></div>
		</nav>

<div class="utama">
	<div class="container1 rounded">
			<!-- <div class="col">Transaksi Baru
				<table class="table">
  				<thead>
    				<tr>
      					<th scope="col">#</th>
      					<th scope="col">First</th>
      					<th scope="col">Last</th>
      					<th scope="col">Handle</th>
    				</tr>
  				</thead>
  				<tbody>
    				<tr>
      					<th scope="row">1</th>
      					<td>Mark</td>
      					<td>Otto</td>
      					<td>@mdo</td>
    				</tr>
    				<tr>
      					<th scope="row">2</th>
      					<td>Jacob</td>
      					<td>Thornton</td>
      					<td>@fat</td>
    				</tr>
  				</tbody>
				</table>
			</div> -->
		<div class="row">Pelanggan Baru
				<table class="tabless table-bordered" style="margin-top: 10px">
  				<thead>
    				<tr>
      					<th scope="col">No</th>
      					<th scope="col">Nama Pelanggan</th>
      					<th scope="col">Alamat</th>
      					<th scope="col">Jenis Kelamin</th>
      					<th scope="col">No. Telepon</th>
    				</tr>
  				</thead>
  				<tbody>
    				<tr>
      					<th scope="row">1</th>
      					<td>Pelanggan1</td>
      					<td>Ciparay</td>
      					<td>Laki-laki</td>
      					<td>085785545321</td>
    				</tr>
    				<tr>
      					<th scope="row">2</th>
      					<td>Pelanggan2</td>
      					<td>Baleendah</td>
      					<td>Perempuan</td>
      					<td>081615718965</td>
    				</tr>
  				</tbody>
				</table>
		</div>
    <div class="row">Pelanggan Baru
        <table class="tabless table-bordered" style="margin-top: 10px">
          <thead>
            <tr>
                <th scope="col">No</th>
                <th scope="col">Nama Pelanggan</th>
                <th scope="col">Alamat</th>
                <th scope="col">Jenis Kelamin</th>
                <th scope="col">No. Telepon</th>
            </tr>
          </thead>
          <tbody>
            <tr>
                <th scope="row">1</th>
                <td>Pelanggan1</td>
                <td>Ciparay</td>
                <td>Laki-laki</td>
                <td>085785545321</td>
            </tr>
            <tr>
                <th scope="row">2</th>
                <td>Pelanggan2</td>
                <td>Baleendah</td>
                <td>Perempuan</td>
                <td>081615718965</td>
            </tr>
          </tbody>
        </table>
    </div>
    <div class="row">Pelanggan Baru
        <table class="tabless table-bordered" style="margin-top: 10px">
          <thead>
            <tr>
                <th scope="col">No</th>
                <th scope="col">Nama Pelanggan</th>
                <th scope="col">Alamat</th>
                <th scope="col">Jenis Kelamin</th>
                <th scope="col">No. Telepon</th>
            </tr>
          </thead>
          <tbody>
            <tr>
                <th scope="row">1</th>
                <td>Pelanggan1</td>
                <td>Ciparay</td>
                <td>Laki-laki</td>
                <td>085785545321</td>
            </tr>
            <tr>
                <th scope="row">2</th>
                <td>Pelanggan2</td>
                <td>Baleendah</td>
                <td>Perempuan</td>
                <td>081615718965</td>
            </tr>
          </tbody>
        </table>
    </div>
    <div class="row">Pelanggan Baru
        <table class="tabless table-bordered" style="margin-top: 10px">
          <thead>
            <tr>
                <th scope="col">No</th>
                <th scope="col">Nama Pelanggan</th>
                <th scope="col">Alamat</th>
                <th scope="col">Jenis Kelamin</th>
                <th scope="col">No. Telepon</th>
            </tr>
          </thead>
          <tbody>
            <tr>
                <th scope="row">1</th>
                <td>Pelanggan1</td>
                <td>Ciparay</td>
                <td>Laki-laki</td>
                <td>085785545321</td>
            </tr>
            <tr>
                <th scope="row">2</th>
                <td>Pelanggan2</td>
                <td>Baleendah</td>
                <td>Perempuan</td>
                <td>081615718965</td>
            </tr>
          </tbody>
        </table>
    </div>
    <div class="row">Pelanggan Baru
        <table class="tabless table-bordered" style="margin-top: 10px">
          <thead>
            <tr>
                <th scope="col">No</th>
                <th scope="col">Nama Pelanggan</th>
                <th scope="col">Alamat</th>
                <th scope="col">Jenis Kelamin</th>
                <th scope="col">No. Telepon</th>
            </tr>
          </thead>
          <tbody>
            <tr>
                <th scope="row">1</th>
                <td>Pelanggan1</td>
                <td>Ciparay</td>
                <td>Laki-laki</td>
                <td>085785545321</td>
            </tr>
            <tr>
                <th scope="row">2</th>
                <td>Pelanggan2</td>
                <td>Baleendah</td>
                <td>Perempuan</td>
                <td>081615718965</td>
            </tr>
          </tbody>
        </table>
    </div>
	</div>
  <div class="container2 rounded">
    <div class="row">Pelanggan Baru
        <table class="tabless table-bordered" style="margin-top: 10px">
          <thead>
            <tr>
                <th scope="col">No</th>
                <th scope="col">Nama Pelanggan</th>
                <th scope="col">Alamat</th>
            </tr>
          </thead>
          <tbody>
            <tr>
                <th scope="row">1</th>
                <td>Pelanggan1</td>
                <td>Ciparay</td>
            </tr>
          </tbody>
        </table>
    </div>
  </div>
</div>

  <footer class="footer p-3">
    <div class="footers text-center">
      <hr/>
      <span>Copyrights • Team 10 @<?= date('Y'); ?></span>
    </div>
  </footer>

	<!-- Bootstrap -->
	<script src="<?= base_url('assets/js/bootsrtap.min.js'); ?>"></script>

</body>
</html>