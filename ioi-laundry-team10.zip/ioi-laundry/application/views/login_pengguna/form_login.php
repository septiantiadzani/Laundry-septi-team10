<!DOCTYPE html>
<html lang="en">
<head>
	<!-- Required meta tags -->
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

	<!-- Koneksi Bootstrap CSS -->
	<link rel="stylesheet" href="<?= base_url('assets/css/bootstrap.min.css'); ?>">

	<link rel="stylesheet" type="text/css" href="<?= base_url('assets/css/laundrycss/css-login.css'); ?>">

	<link rel="shortcut icon" href="<?= base_url('assets/logo-laundry2.png'); ?>">

	<title>Login | IOI Laundry</title>
</head>
<body>
	<?php
		if (isset($_GET['alert'])) {
			if ($_GET['alert']=="gagal") {
				echo "<div class='alert alert-danger fixed-top font-weight-bold text-center'>Maaf! Username & Password Salah</div>";
			} elseif ($_GET['alert']=="belum_login") {
				echo "<div class='alert alert-danger fixed-top font-weight-bold text-center'>Anda Harus Login Terlebih Dahulu!</div>";
			} elseif ($_GET['alert']=="logout") {
				echo "<div class='alert alert-success fixed-top font-weight-bold text-center'>Anda Telah Logout!</div>";
			}
		}
	?>

	<div class="utama">
	<div class="container1">
		<img class="img disable" src="<?= base_url('assets/logo-laundry1.png'); ?>" width="600" height="600">
	</div>
	
	<div class="container2">
	<div class="card">
		<div class="card-body">
			<h3 class="card-title text-center"><b>WELCOME</b></h3>
			<hr/>
			<form action="<?= base_url().'login_pengguna/ceklogin'; ?>" method="post">
				<div class="form-group">
					<label class="form-label" for="username">Username</label>
					<input type="text" id="username" class="form-control" name="username" placeholder="Masukkan Username" style="margin-bottom: 10px" autocomplete="off" required autofocus>
				</div>
				<div class="form-group">
					<label class="form-label" for="password">Password</label>
					<input type="password" id="password" class="form-control" name="password" placeholder="Masukkan Password" style="margin-bottom: 10px" autocomplete="off" required>
					<div class="showhidepass">
						<input type="checkbox" onclick="showpw()" style="margin-bottom: 10px">
						Tampilkan Password
					</div>
				</div>
				<button type="submit" class="btn btn-sm">Login</button>
			</form>
		</div>
	</div>
	</div>
	</div>

	<!-- <footer id="sticky-footer" class="footer p-3 fixed-bottom foots">
    	<div class="footers text-center">
      		<hr/>
      		<span>Copyrights <?= date('Y'); ?> IOI Laundry | Team 10</span>
    	</div>
 	</footer> -->

	<!-- Bootstrap -->
	<!-- <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>
  	<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.10.2/dist/umd/popper.min.js" integrity="sha384-7+zCNj/IqJ95wo16oMtfsKbZ9ccEh31eOz1HGyDuCQ6wgnyJNSYdrPa03rtR1zdB" crossorigin="anonymous"></script>
	<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.min.js" integrity="sha384-QJHtvGhmr9XOIpI6YVutG+2QOK9T+ZnN4kzFN1RtK3zEFEIsxhlmWl5/YESvpZ13" crossorigin="anonymous"></script> -->
	<script src="<?= base_url('assets/js/bootsrtap.min.js'); ?>"></script>
	<script src="<?= base_url('assets/js/jquery-3.4.1.min'); ?>"></script>
	<script type="text/javascript">
		function showpw() {
            var x = document.getElementById("password");
            if (x.type === "password") {
                x.type = "text";
            } else {
                x.type = "password";
            }
        }
	</script>
</body>
</html>