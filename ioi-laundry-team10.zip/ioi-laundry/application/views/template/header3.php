<!DOCTYPE html>
<html lang="en">
<head>
	<!-- Required meta tags -->
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

	<!-- Koneksi Bootstrap CSS -->
  <!-- <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous"> -->

	<link rel="stylesheet" href="<?= base_url('assets/css/bootstrap.min.css'); ?>">

	<link rel="stylesheet" type="text/css" href="<?= base_url('assets/css/laundrycss/for-all.css'); ?>">

  <link rel="shortcut icon" href="<?= base_url('assets/logo-laundry2.png'); ?>">

	<title><?= $judul_part; ?></title>
</head>

<body>
	<nav class="navbar navbar-expand-lg sticky-top navbarlight">
        <a class="navbar-brand" target="_blank" href="<?= base_url('assets/logo-laundry1.png'); ?>">
          <img src="<?= base_url('assets/logo-laundry1.png'); ?>" width="40" height="40">
        </a>
        <!-- <button class="navbar-toggle" type="button" data-toggle="collapse" data-target="#navbarNavAltMarkup"
        aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggle-icon"></span>
        </button> -->
  			<div class="collapse navbar-collapse" id="navbarNavAltMarkup">
    		<ul class="navbar-nav">
      			<li class="nav-item <?= ($page=='owner')?$status_page :''; ?>"> <a href="<?= site_url('owner'); ?>" class="nav-link">Dashboard</a> </li>
				    <li class="nav-item <?= ($page=='laporan')?$status_page :''; ?>"> <a href="<?= site_url('owner/laporan'); ?>" class="nav-link">Data Laporan</a> </li>
    		</ul>
  			</div>
        <div class="profile">
          <div class="ikon">
            <img src="<?= base_url('assets/icon/account_circle_white_24dp.svg'); ?>" class="pp" width="30" height="30">
          </div>
          <div class="text">
            <div class="text-user">
              <?= $this->session->userdata('username'); ?>
            </div>
            <div class="text-role">
            	<?= $this->session->userdata('role'); ?>
            </div>
          </div>
        </div>
        <div class="out">
        	<a href="<?= base_url().'owner/keluar'; ?>" onclick="return confirm('Apakah Anda Ingin Logout?')" role="button" class="btn btnout btn-danger btn-block"><img src="<?= base_url('assets/icon/logout_white_24dp.svg'); ?>" width="20" height="20">Logout</a>
        </div>
		</nav>