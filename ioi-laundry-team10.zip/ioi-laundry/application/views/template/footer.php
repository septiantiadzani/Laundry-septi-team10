	<div class="rightside">
  <div class="container2 rounded">
    <div class="row text-center align-middle">
      <h1 style="font-size: 30pt; color: #0D1B2A"><?= $total_pelanggan; ?>
        <img src="<?= base_url('assets/icon/people_black_24dp.svg'); ?>" width="40" height="40">
      </h1><i>Total Pelanggan</i>
    </div>
  </div>
  <div class="container2 rounded">
    <div class="row text-center align-middle">
      <h1 style="font-size: 30pt; color: #0D1B2A"><?= $total_transaksi; ?>
        <img src="<?= base_url('assets/icon/paid_black_24dp.svg'); ?>" width="40" height="40">
      </h1><i>Total Transaksi</i> 
    </div>
  </div>
  <div class="container2 rounded">
    <div class="row text-center align-middle">
      <h1 style="font-size: 30pt; color: #0D1B2A"><?= $total_paket; ?>
        <img src="<?= base_url('assets/icon/local_laundry_service_black_24dp.svg'); ?>" width="40" height="40">
      </h1><i>Total Paket</i> 
    </div>
  </div>
  <div class="container2 rounded">
    <div class="row text-center align-middle">
      <h1 style="font-size: 30pt; color: #0D1B2A"><?= $total_outlet; ?>
        <img src="<?= base_url('assets/icon/store_black_24dp.svg'); ?>" width="40" height="40">
      </h1><i>Total Outlet</i> 
    </div>
  </div>
  </div>
  </div>

  <footer id="sticky-footer" class="footer p-3 fixed-bottom foots">
    	<div class="footers text-center">
      		<!-- <hr/> -->
      		<span>Copyrights <?= date('Y'); ?> IOI Laundry | Team 10</span>
    	</div>
 	</footer>
	
	<!-- Bootstrap -->
  <!-- <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>
  <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.10.2/dist/umd/popper.min.js" integrity="sha384-7+zCNj/IqJ95wo16oMtfsKbZ9ccEh31eOz1HGyDuCQ6wgnyJNSYdrPa03rtR1zdB" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.min.js" integrity="sha384-QJHtvGhmr9XOIpI6YVutG+2QOK9T+ZnN4kzFN1RtK3zEFEIsxhlmWl5/YESvpZ13" crossorigin="anonymous"></script> -->
	<script src="<?= base_url('assets/js/bootstrap.min.js'); ?>"></script>
  <script src="<?= base_url('assets/js/jquery-3.4.1.min.js'); ?>"></script>
  <!-- <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script> -->

  <script>
    $('#jenis_paket').change(function() {
      var id_paket = $(this).val();

      $.ajax({
      url : '<?= base_url().'admin/getharga'; ?>',
      data : {id_paket : id_paket},
      method : 'post',
      dataType : 'JSON',
      success : function(hasil){
        $('#harga').val(hasil.harga_paket);
      }

      });
    });

    $('#berat').keyup(function(){
      var berat = $(this).val();
      var harga = document.getElementById('harga').value;
      $('#grand_total').val(berat * harga);
    })
  </script>
	
</body>
</html>