<!DOCTYPE html>
<html lang="en">
<head>
	<!-- Required meta tags -->
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

	<!-- Koneksi Bootstrap CSS -->
	<link rel="stylesheet" href="<?= base_url('assets/css/bootstrap.min.css'); ?>">

	<title>Data Paket | Team 10</title>

	<style type="text/css">
		* {
			font-family: arial;
		}
	</style>
</head>

<body style="background-color: #11151C"> <!-- class="bg-secondary" -->
	<header style="padding-left: 3rem; padding-top: 1rem; padding-bottom: 1rem; margin-bottom: 2rem; background-color: #F5FBEF">
		<h2>Aplikasi Pengelolaan Laundry*</h2>
		<nav class="navbar navbar-expand-lg sticky-top navbar-light bg-white" style="margin-right: 40%">
  			<div class="collapse navbar-collapse" id="navbarNavAltMarkup">
    		<div class="navbar-nav">
      			<a class="nav-item nav-link" href="<?= site_url('admin'); ?>">Dashboard</a>
      			<a class="nav-item nav-link active" href="<?= site_url('paket'); ?>">Data Paket</a>
      			<a class="nav-item nav-link" href="<?= site_url('outlet'); ?>">Data Outlet</a>
      			<a class="nav-item nav-link" href="<?= site_url('pengguna'); ?>">Data Pengguna</a>
				<a class="nav-item nav-link" href="<?= site_url('pelanggan'); ?>">Data Pelanggan</a>
				<a class="nav-item nav-link" href="#">Data Transaksi</a>
				<a class="nav-item nav-link" href="#">Data Laporan</a>
    		</div>
  			</div>
		</nav>
	</header>

	<div class="container p-4 rounded col-md-8" style="margin-left: 3rem; background-color: #F5FBEF; margin-top: 2rem;
	margin-bottom: 2rem;">
		<h3>List Paket Cucian</h3>
		<table class="table table-bordered border-dark">
			<thead class="text-center">
				<tr>
					<th scope="col">No</th>
					<th width="50">ID_Outlet</th>
					<th scope="col">Nama Paket</th>
					<th scope="col">Jenis Paket</th>
					<th scope="col">Harga</th>
					<th width="150">Aksi</th>
				</tr>
			</thead>
			<?php
				$count = 0;
				foreach ($paket->result() as $row) :
					$count++;
			?>
			<tr>
				<th scope="row" class="text-center"><?= $count; ?></th>
				<td class="text-center"><?= $row->id_outlet; ?></td>
				<td><?= $row->nama_paket; ?></td>
				<td class="text-center"><?= $row->jenis_paket; ?></td>
				<td class="text-center"><?= $row->harga_paket; ?></td>
				<td class="text-center">
					<a href="<?= site_url('paket/edit/'.$row->id_paket); ?>" class="btn btn-sm btn-primary">Update</a>
					<a href="<?= site_url('paket/delete/'.$row->id_paket); ?>" class="btn btn-sm btn-danger">Delete</a>
				</td>
			</tr>
		<?php endforeach; ?>
		</table>
		<a href="<?= site_url('paket/add_new'); ?>" class="btn btn-primary">Tambah Paket</a>
	</div>

	<footer class="footer p-3">
		<div class="container text-center text-white">
			<hr/>
			<span>Team 10 @<?= date('Y'); ?></span>
		</div>
	</footer>
	
	<!-- Bootstrap -->
	<script src="<?= base_url('assets/js/bootsrtap.min.js'); ?>"></script>
	<script src="<?= base_url('assets/js/jquery.min.js'); ?>"></script>
</body>
</html>