<!DOCTYPE html>
<html lang="en">
<head>
	<!-- Required meta tags -->
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">

	<!-- Koneksi Bootstrap CSS -->
	<link rel="stylesheet" href="<?= base_url('assets/css/bootstrap.min.css'); ?>">

	<title>Form Login | Team 10</title>
</head>
<body>
	<?php
		// if (isset($_GET['alert'])) {
		// 	if ($_GET['alert']=="gagal") {
		// 		echo "<div class='alert alert_danger font-weight-bold text-center'>Maaf! Username & Password Salah.</div>";
		// 	} elseif ($_GET['alert']=="belum_login") {
		// 		echo "<div class='alert alert_danger font-weight-bold text-center'>Anda Harus Login Terlebih Dahulu!</div>";
		// 	} elseif ($_GET['alert']=="logout") {
		// 		echo "<div class='alert alert_success font-weight-bold text-center'>Anda Telah Logout!</div>";
		// 	}
		// }
	?>

	<div class="card position-absolute top-50 start-50 translate-middle bg-light" style="width: 30rem;">
		<div class="card-body">
			<h3 class="card-title text-center">LOGIN</h3>
			<?php
				if ($this->session->flashdata('error_login') !='')
				{
					echo "<div class='alert alert-danger' role='alert'>";
					echo $this->session->flashdata('error_login');
					echo "</div>";
				}
			?>

			<?php
				if ($this->session->flashdata('success_register') !='')
				{
					echo "<div class='alert alert-info' role='alert'>";
					echo $this->session->flashdata('success_register');
					echo "</div>";
				}
			?>

			<form action="<?= site_url('login/proses_login'); ?>" method="post">
				<div class="form-group">
					<label class="form-label" for="username">Username</label>
					<input type="text" id="username" class="form-control" placeholder="Masukkan Username" style="margin-bottom: 10px">
				</div>
				<div class="form-group">
					<label class="form-label" for="password">Password</label>
					<input type="password" id="password" class="form-control" placeholder="Masukkan Password" style="margin-bottom: 10px">
				</div>
				<button type="submit" class="btn btn-primary">Login</button>
			</form>
		</div>
	</div>

	<!-- Bootstrap -->
	<script src="<?= base_url('assets/js/bootsrtap.min.js'); ?>"></script>
	<script src="<?= base_url('assets/js/jquery.min.js'); ?>"></script>
</body>
</html>