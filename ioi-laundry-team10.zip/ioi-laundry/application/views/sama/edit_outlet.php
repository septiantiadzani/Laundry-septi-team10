<!DOCTYPE html>
<html lang="en">
<head>
	<!-- Required meta tags -->
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">

	<!-- Koneksi Bootstrap CSS -->
	<link rel="stylesheet" href="<?= base_url('assets/css/bootstrap.min.css'); ?>">

	<title>Edit Outlet | Team 10</title>
</head>

<body style="background-color: #11151C"> <!-- class="bg-secondary" -->
	<header style="padding-left: 3rem; padding-top: 1rem; padding-bottom: 1rem; margin-bottom: 2rem; background-color: #F5FBEF">
		<h2>Aplikasi Pengelolaan Laundry*</h2>
		<nav class="navbar navbar-expand-lg sticky-top navbar-light bg-white" style="margin-right: 40%">
  			<div class="collapse navbar-collapse" id="navbarNavAltMarkup">
    		<div class="navbar-nav">
      			<a class="nav-item nav-link" href="<?= site_url('admin'); ?>">Dashboard</a>
      			<a class="nav-item nav-link" href="<?= site_url('paket'); ?>">Data Paket</a>
      			<a class="nav-item nav-link active" href="<?= site_url('outlet'); ?>">Data Outlet</a>
      			<a class="nav-item nav-link" href="<?= site_url('pengguna'); ?>">Data Pengguna</a>
				<a class="nav-item nav-link" href="<?= site_url('pelanggan'); ?>">Data Pelanggan</a>
				<a class="nav-item nav-link" href="#">Data Transaksi</a>
				<a class="nav-item nav-link" href="#">Data Laporan</a>
    		</div>
  			</div>
		</nav>
	</header>

	<div class="container p-4 rounded col-md-6" style="margin-left: 3rem; background-color: #F5FBEF; margin-top: 2rem;
	margin-bottom: 2rem;">
		<h4>Edit Outlet</h4>
			<form action="<?= site_url('outlet/update'); ?>" method="post">
				<div class="form-group" style="margin-bottom: 15px">
					<label for="nama_outlet">Nama Outlet</label>
					<input type="text" class="form-control" name="nama_outlet" id="nama_outlet" value="<?= $nama_outlet; ?>" placeholder="Nama Outlet">
				</div>
				<div class="form-group" style="margin-bottom: 15px">
					<label for="alamat">Alamat</label>
					<input type="text" class="form-control" name="alamat" id="alamat" value="<?= $alamat; ?>" placeholder="Alamat Outlet">
				</div>
				<div class="form-group" style="margin-bottom: 15px">
					<label for="tlp">No. Telepon</label>
					<input type="text" class="form-control" name="tlp" id="tlp" value="<?= $tlp; ?>" placeholder="No. Telepon">
				</div>
				<input type="hidden" name="id_outlet" value="<?= $id_outlet; ?>">
				<button type="submit" class="btn btn-primary">Update</button>
			</form>
	</div>
	<!-- Bootstrap -->
	<script src="<?= base_url('assets/js/bootsrtap.min.js'); ?>"></script>
	<script src="<?= base_url('assets/js/jquery.min.js'); ?>"></script>
</body>
</html>