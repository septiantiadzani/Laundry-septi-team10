<!DOCTYPE html>
<html lang="en">
<head>
	<!-- Required meta tags -->
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">

	<!-- Koneksi Bootstrap CSS -->
	<link rel="stylesheet" href="<?= base_url('assets/css/bootstrap.min.css'); ?>">

	<title>Registrasi Pelanggan | Team 10</title>
</head>

<body>
	<div class="container">
		<div class="card">
			<div class="card-header">
				Form Registrasi Pelanggan
			</div>
			<div class="card-body">
				<?php
					if ($this->session->flashdata('error') !='')
					{
					 	echo "<div class='alert alert-danger' role='alert'>";
					 	echo $this->session->flashdata('error');
					 	echo "</div>";
					} 
				?>

				<form method="post" action="<?= site_url('register/proses/'); ?>">
					<div class="form-group">
						<label for="nama_pelanggan">Nama Pelanggan</label>
						<input type="text" name="nama_pelanggan" id="nama_pelanggan" class="form-control" placeholder="Masukkan Nama Pelanggan">
					</div>
					<div class="form-group">
						<label for="alamat">Alamat</label>
						<input type="text" name="alamat" id="alamat" class="form-control" placeholder="Masukkan Alamat">
					</div>
					<div class="form-group">
						<label for="jenis_kelamin">Jenis Kelamin</label>
						<select name="jenis_kelamin" class="form-control" id="jenis_kelamin">
							<option value="laki-laki">Laki-laki</option>
							<option value="perempuan">Perempuan</option>
						</select>
					</div>
					<div class="form-group">
						<label for="tlp">No. Telepon</label>
						<input type="text" name="tlp" id="tlp" class="form-control" placeholder="Masukkan No. Telepon">
					</div>
					<button type="submit" class="btn btn-primary">Daftar</button>
				</form>
			</div>
		</div>
	</div>

	<script src="<?= base_url('assets/js/bootsrtap.min.js'); ?>"></script>
	<script src="<?= base_url('assets/js/jquery.min.js'); ?>"></script>

</body>
</html>