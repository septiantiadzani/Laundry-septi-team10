<!DOCTYPE html>
<html lang="en"<
	<head>
		<meta charset="utf-8">
		<title><?= $title; ?></title>
		<!-- load bootstrap css file -->
		<link rel="stylesheet" href="<?php echo base_url('assets/css/bootstrap.min.css'); ?>">
	</head>
	<body>
		<h1><?= $content1; ?></h1>
		<i><h2><?= $content2; ?></h2></i>
		<b><h3><?= $content3; ?></h3></b>
		<small><h4><?= $content4; ?></h4></small>
		<!-- load bootstrap js file -->
		<script src="<?php echo base_url('assets/js/bootstrap.min.js'); ?>"></script>
	</body>
</html>