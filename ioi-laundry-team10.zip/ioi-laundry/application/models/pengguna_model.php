<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Pengguna_model extends CI_Model {
	function get_pengguna() {
		$this->db->order_by('id_user','desc');
		return $this->db->get('user');
	}

	function get_pengguna_role() {
		$this->db->order_by('id_user','desc');
		$this->db->where_in('role', array('admin', 'kasir'));
		return $this->db->get('user');
	}

	function tambah($nama_user,$username,$password,$id_outlet,$role)
	{
		$data = array(
			'nama_user' => $nama_user,
			'username' => $username,
			'password' => $password,
			'id_outlet' => $id_outlet,
			'role' => $role
		);
		$this->db->insert('user',$data);
	}

	function get_id_user($id_user)
	{
		$query = $this->db->get_where('user', array('id_user' => $id_user));
		return $query;
	}

	function updatepengguna($id_user,$nama_user,$username,$password,$id_outlet,$role)
	{
		$data = array(
			'nama_user' => $nama_user,
			'username' => $username,
			'password' => $password,
			'id_outlet' => $id_outlet,
			'role' => $role
		);
		$this->db->where('id_user', $id_user);
		$this->db->update('user',$data);
	}

	function delete($id_user)
	{
		$this->db->where('id_user', $id_user);
		$this->db->delete('user');
	}

	function data($number,$offset,$keyword = null)
	{
		$this->db->order_by('id_user','desc');

		if ($keyword) {
			$this->db->like('nama_user', $keyword);
			$this->db->or_like('username', $keyword);
			$this->db->or_like('id_outlet', $keyword);
			$this->db->or_like('role', $keyword);
		}
		return $query = $this->db->get('user',$number,$offset)->result();
	}

	function jumlah_data()
	{
		return $this->db->get('user')->num_rows();
	}
}
?>