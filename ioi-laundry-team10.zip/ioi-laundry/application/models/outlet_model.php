<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Outlet_model extends CI_Model {
	function get_outlet() {
		$this->db->order_by('id_outlet','desc');
		return $this->db->get('outlet');
	}

	function tambah($nama_outlet,$alamat,$tlp)
	{
		$data = array(
			'nama_outlet' => $nama_outlet,
			'alamat' => $alamat,
			'tlp' => $tlp
		);
		$this->db->insert('outlet',$data);
	}

	function get_id_outlet($id_outlet)
	{
		$query = $this->db->get_where('outlet', array('id_outlet' => $id_outlet));
		return $query;
	}

	function updateoutlet($id_outlet,$nama_outlet,$alamat,$tlp)
	{
		$data = array(
			'nama_outlet' => $nama_outlet,
			'alamat' => $alamat,
			'tlp' => $tlp
		);
		$this->db->where('id_outlet', $id_outlet);
		$this->db->update('outlet',$data);
	}

	function delete($id_outlet)
	{
		$this->db->where('id_outlet', $id_outlet);
		$this->db->delete('outlet');
	}

	function data($number,$offset,$keyword = null)
	{
		$this->db->order_by('id_outlet','desc');

		if ($keyword) {
			$this->db->like('nama_outlet', $keyword);
			$this->db->or_like('alamat', $keyword);
			$this->db->or_like('tlp', $keyword);
		}

		return $query = $this->db->get('outlet',$number,$offset)->result();
	}

	function jumlah_data()
	{
		return $this->db->get('outlet')->num_rows();
	}

	function hitung_outlet()
	{
		$query = $this->db->get('outlet');
		if ($query->num_rows() > 0) {
			return $query->num_rows();
		} else {
			return 0;
		}
	}
}
?>