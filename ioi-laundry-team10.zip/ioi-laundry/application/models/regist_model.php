<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Regist_model extends CI_Model {
	function registerr($nama_pelanggan,$alamat,$jenis_kelamin,$tlp)
	{
		$data_pelanggan = array(
			'nama_pelanggan' => $nama_pelanggan,
			'alamat' => $alamat,
			'jenis_kelamin' => $jenis_kelamin,
			'tlp' => $tlp
		);
		$this->db->insert('pelanggan',$data_pelanggan);
	}
}
?>