<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Transaksi_model extends CI_Model {
	function get_transaksi() {
		$this->db->order_by('id_transaksi','desc');
		return $this->db->get('transaksi');
	}

	function tambah($id_outlet,$kode_invoice,$id_pelanggan,$tgl,$batas_waktu,$tgl_bayar,$berat,$grand_total,$status,$dibayar,$id_user)
	{
		$data = array(
			'id_outlet' => $id_outlet,
			'kode_invoice' => $kode_invoice,
			'id_pelanggan' => $id_pelanggan,
			'tgl' => $tgl,
			'batas_waktu' => $batas_waktu,
			'tgl_bayar' => $tgl_bayar,
			'berat' => $berat,
			'grand_total' => $grand_total,
			// 'jumlah_cucian' => $jumlah_cucian,
			// 'biaya_tambahan' => $biaya_tambahan,
			// 'diskon' => $diskon,
			// 'pajak' => $pajak,
			'status' => $status,
			'dibayar' => $dibayar,
			'id_user' => $id_user
		);
		$this->db->insert('transaksi',$data);
	}

	function get_id_transaksi($id_transaksi)
	{
		$query = $this->db->get_where('transaksi', array('id_transaksi' => $id_transaksi));
		return $query;
	}

	function updatetransaksi($id_transaksi,$id_outlet,$kode_invoice,$id_pelanggan,$tgl,$batas_waktu,$tgl_bayar,$berat,$grand_total,$status,$dibayar,$id_user)
	{
		$data = array(
			'id_outlet' => $id_outlet,
			'kode_invoice' => $kode_invoice,
			'id_pelanggan' => $id_pelanggan,
			'tgl' => $tgl,
			'batas_waktu' => $batas_waktu,
			'tgl_bayar' => $tgl_bayar,
			'berat' => $berat,
			'grand_total' => $grand_total,
			// 'jumlah_cucian' => $jumlah_cucian,
			// 'biaya_tambahan' => $biaya_tambahan,
			// 'diskon' => $diskon,
			// 'pajak' => $pajak,
			'status' => $status,
			'dibayar' => $dibayar,
			'id_user' => $id_user
		);
		$this->db->where('id_transaksi', $id_transaksi);
		$this->db->update('transaksi',$data);
	}

	// function delete($id_outlet)
	// {
	// 	$this->db->where('id_outlet', $id_outlet);
	// 	$this->db->delete('outlet');
	// }

	function data($number,$offset,$keyword = null)
	{
		$this->db->order_by('id_transaksi','desc');

		if ($keyword) {
			$this->db->like('id_pelanggan', $keyword);
			$this->db->or_like('tgl', $keyword);
			$this->db->or_like('batas_waktu', $keyword);
			$this->db->or_like('tgl_bayar', $keyword);
			$this->db->or_like('status', $keyword);
			$this->db->or_like('dibayar', $keyword);
			$this->db->or_like('id_user', $keyword);
		}

		return $query = $this->db->get('transaksi',$number,$offset)->result();
	}

	function data_transaksi_baru($number,$offset,$keyword = null)
	{
		$this->db->order_by('id_transaksi','desc');

		if ($keyword) {
			$this->db->like('id_pelanggan', $keyword);
			$this->db->or_like('tgl', $keyword);
			$this->db->or_like('batas_waktu', $keyword);
			$this->db->or_like('tgl_bayar', $keyword);
			$this->db->or_like('status', $keyword);
			$this->db->or_like('dibayar', $keyword);
			$this->db->or_like('id_user', $keyword);
		}

		return $this->db->get_where('transaksi', array('status' => 'baru'),$number,$offset)->result();
		// return $query = $this->db->get('transaksi',$number,$offset)->result();
	}

	function jumlah_data()
	{
		return $this->db->get('transaksi')->num_rows();
	}

	function join_transaksi_paket()
	{
		$this->db->select('*');
		$this->db->from('transaksi');
		$this->db->join('paket_cucian','paket_cucian.id_paket=transaksi.id_transaksi');
		$query = $this->db->get();
		return $query;
	}

	function gethargapaket($id_paket)
	{
		$this->db->order_by('id_paket','desc');
		$this->db->where('id_paket', $id_paket);
		return $this->db->get('paket_cucian')->row_array();
	}

	function hitung_transaksi()
	{
		$query = $this->db->get('transaksi');
		if ($query->num_rows() > 0) {
			return $query->num_rows();
		} else {
			return 0;
		}
	}
}
?>