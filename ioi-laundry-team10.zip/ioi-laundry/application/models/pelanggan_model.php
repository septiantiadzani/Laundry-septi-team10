<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Pelanggan_model extends CI_Model {
	function get_pelanggan() {
		$this->db->order_by('id_pelanggan','desc');
		return $this->db->get('pelanggan');
	}

	function tambah($nama_pelanggan,$alamat,$jenis_kelamin,$tlp)
	{
		$data = array(
			'nama_pelanggan' => $nama_pelanggan,
			'alamat' => $alamat,
			'jenis_kelamin' => $jenis_kelamin,
			'tlp' => $tlp
		);
		$this->db->insert('pelanggan',$data);
	}

	function get_id_pelanggan($id_pelanggan)
	{
		$query = $this->db->get_where('pelanggan', array('id_pelanggan' => $id_pelanggan));
		return $query;
	}

	function update($id_pelanggan,$nama_pelanggan,$alamat,$jenis_kelamin,$tlp)
	{
		$data = array(
			'id_pelanggan' => $id_pelanggan,
			'nama_pelanggan' => $nama_pelanggan,
			'alamat' => $alamat,
			'jenis_kelamin' => $jenis_kelamin,
			'tlp' => $tlp
		);
		$this->db->where('id_pelanggan', $id_pelanggan);
		$this->db->update('pelanggan',$data);
	}

	function delete($id_pelanggan)
	{
		$this->db->where('id_pelanggan', $id_pelanggan);
		$this->db->delete('pelanggan');
	}

	function data($number,$offset,$keyword = null)
	{
		$this->db->order_by('id_pelanggan','desc');

		if ($keyword) {
			$this->db->like('nama_pelanggan', $keyword);
			$this->db->or_like('alamat', $keyword);
			$this->db->or_like('jenis_kelamin', $keyword);
			$this->db->or_like('tlp', $keyword);
		}

		return $query = $this->db->get('pelanggan',$number,$offset)->result();
	}

	function jumlah_data()
	{
		return $this->db->get('pelanggan')->num_rows();
	}

	function hitung_pelanggan()
	{
		$query = $this->db->get('pelanggan');
		if ($query->num_rows() > 0) {
			return $query->num_rows();
		} else {
			return 0;
		}
	}
}
?>