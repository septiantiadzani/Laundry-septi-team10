<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Laporan_model extends CI_Model {
	function get_laporan() {
		$this->db->order_by('id_laporan','desc');
		return $this->db->get('laporan');
	}

	// function hitung_laporan()
	// {
	// 	$query = $this->db->get('laporan');
	// 	if ($query->num_rows() > 0) {
	// 		return $query->num_rows();
	// 	} else {
	// 		return 0;
	// 	}
	// }
}
?>