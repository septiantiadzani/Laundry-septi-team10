<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class M_data extends CI_Model {

	function __construct()
	{
		parent::__construct();
	}

	public function login_user($username,$password)
	{
		$query = $this->db->get_where('user', array('username'=>$username));
		if ($query->num_rows() > 0)
		{
			$data_user = $query->row();
			if (password_verify($password, $data_user->password))
			{
				$this->session->set_userdata('username',$username);
				$this->session->set_userdata('nama_user',$data_user->nama_user);
				$this->session->set_userdata('is_login',TRUE);
				return TRUE;
			} else {
				return FALSE;
			}
		} else {
			return FALSE;
		}
	}

	function cek_login1()
	{
		if (empty($this->session->userdata('is_login')))
		{
			redirect('login');
		}
	}

	function daftar_user($nama_user,$username,$password,$id_outlet,$role)
	{
		$data_user = array(
			'nama_user' => $nama_user,
			'username' => $username,
			'password' => $password,
			'id_outlet' => $id_outlet,
			'role' => $role
		);
		$this->db->insert('user',$data_user);
	}

	function cek_login($table,$where)
	{
		return $this->db->get_where('user',$where);
	}
}
?>