<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Paket_model extends CI_Model {
	function get_paket() {
		$this->db->order_by('id_paket','desc');
		return $this->db->get('paket_cucian');
	}

	function tambah($id_outlet,$nama_paket,$jenis_paket,$harga_paket)
	{
		$data = array(
			'id_outlet' => $id_outlet,
			'nama_paket' => $nama_paket,
			'jenis_paket' => $jenis_paket,
			'harga_paket' => $harga_paket
		);
		$this->db->insert('paket_cucian',$data);
	}

	function get_id_paket($id_paket)
	{
		$query = $this->db->get_where('paket_cucian', array('id_paket' => $id_paket));
		return $query;
	}

	function updatepaket($id_paket,$id_outlet,$nama_paket,$jenis_paket,$harga_paket)
	{
		$data = array(
			'id_outlet' => $id_outlet,
			'nama_paket' => $nama_paket,
			'jenis_paket' => $jenis_paket,
			'harga_paket' => $harga_paket
		);
		$this->db->where('id_paket', $id_paket);
		$this->db->update('paket_cucian',$data);
	}

	function delete($id_paket)
	{
		$this->db->where('id_paket', $id_paket);
		$this->db->delete('paket_cucian');
	}

	function data($number,$offset,$keyword = null)
	{
		$this->db->order_by('id_paket','desc');
		
		if ($keyword) {
			$this->db->like('nama_paket', $keyword);
			$this->db->or_like('jenis_paket', $keyword);
			$this->db->or_like('harga_paket', $keyword);
			$this->db->or_like('id_outlet', $keyword);
		}

		return $query = $this->db->get('paket_cucian',$number,$offset)->result();
	}

	function jumlah_data()
	{
		return $this->db->get('paket_cucian')->num_rows();
	}

	function hitung_paket()
	{
		$query = $this->db->get('paket_cucian');
		if ($query->num_rows() > 0) {
			return $query->num_rows();
		} else {
			return 0;
		}
	}
}
?>