<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Owner extends CI_Controller {
	function __construct()
	{
		parent::__construct();

		date_default_timezone_set('Asia/Jakarta');

		$this->load->helper(array('url'));

		$this->load->model('login_model','transaksi_model','laporan_model');

		if ($this->session->userdata('status')!="telah_login_owner") {
			redirect(base_url().'login_pengguna?alert=belum_login');
		}
	}

	public function index() 
	{
		$data['judul_part'] = "Dashboard Owner | IOI Laundry";
		$data['page'] = $this->uri->segment(1);
		$data['status_page'] = "active";
		$data['total_paket'] = $this->paket_model->hitung_paket();
		$data['total_pelanggan'] = $this->pelanggan_model->hitung_pelanggan();
		$data['total_transaksi'] = $this->transaksi_model->hitung_transaksi();
		$data['total_outlet'] = $this->outlet_model->hitung_outlet();

		$this->load->database();

		// $jumlah_data = $this->transaksi_model->jumlah_data();

		$this->load->library('pagination');

		if ($this->input->post('submit')) {
			$data['keyword'] = $this->input->post('keyword');
			$this->session->set_userdata('keyword', $data['keyword']);
		} else {
			$data['keyword'] = $this->session->userdata('keyword');
		}

		$config['base_url'] = base_url().'owner/index/';

		$this->db->like('id_pelanggan', $data['keyword']);
		$this->db->or_like('tgl', $data['keyword']);
		$this->db->or_like('batas_waktu', $data['keyword']);
		$this->db->or_like('tgl_bayar', $data['keyword']);
		$this->db->like('status', $data['keyword']);
		$this->db->or_like('dibayar', $data['keyword']);
		$this->db->or_like('id_user', $data['keyword']);
		$this->db->from('transaksi');

		$config['total_rows'] = $this->db->count_all_results();

		$config['per_page'] = 7;

		$config['attributes'] = array('class' => 'page-link');
		
		$from = $this->uri->segment(3);
		
		$this->pagination->initialize($config);

		$data['transaksi'] = $this->transaksi_model->data_transaksi_baru($config['per_page'], $from, $data['keyword']);

		$this->load->view('template/header3', $data);
		$this->load->view('Owner/dashboard_owner', $data);
		$this->load->view('template/footer', $data);
	}

	public function keluar() 
	{
		$this->session->sess_destroy();
		redirect('login_pengguna?alert=logout');
	}
}
?>