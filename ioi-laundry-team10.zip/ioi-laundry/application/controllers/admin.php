<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Admin extends CI_Controller {
	function __construct()
	{
		parent::__construct();

		date_default_timezone_set('Asia/Jakarta');

		$this->load->helper(array('url'));

		$this->load->model('login_model','paket_model','outlet_model','pengguna_model','pelanggan_model','regist_model','transaksi_model','laporan_model');

		if ($this->session->userdata('status') != "telah_login_admin") {
			redirect(base_url().'login_pengguna?alert=belum_login');
		}
	}

	public function index() 
	{
		$data['judul_part'] = "Dashboard Admin | IOI Laundry";
		$data['page'] = $this->uri->segment(1);
		$data['status_page'] = "active";
		$data['total_paket'] = $this->paket_model->hitung_paket();
		$data['total_pelanggan'] = $this->pelanggan_model->hitung_pelanggan();
		$data['total_transaksi'] = $this->transaksi_model->hitung_transaksi();
		$data['total_outlet'] = $this->outlet_model->hitung_outlet();

		$this->load->database();

		// $jumlah_data = $this->transaksi_model->jumlah_data();

		$this->load->library('pagination');

		if ($this->input->post('submit')) {
			$data['keyword'] = $this->input->post('keyword');
			$this->session->set_userdata('keyword', $data['keyword']);
		} else {
			$data['keyword'] = $this->session->userdata('keyword');
		}

		$config['base_url'] = base_url().'admin/index/';

		$this->db->like('id_pelanggan', $data['keyword']);
		$this->db->or_like('tgl', $data['keyword']);
		$this->db->or_like('batas_waktu', $data['keyword']);
		$this->db->or_like('tgl_bayar', $data['keyword']);
		$this->db->like('status', $data['keyword']);
		$this->db->or_like('dibayar', $data['keyword']);
		$this->db->or_like('id_user', $data['keyword']);
		$this->db->from('transaksi');

		$config['total_rows'] = $this->db->count_all_results();

		$config['per_page'] = 7;

		$config['attributes'] = array('class' => 'page-link');
		
		$from = $this->uri->segment(3);
		
		$this->pagination->initialize($config);

		$data['transaksi'] = $this->transaksi_model->data_transaksi_baru($config['per_page'], $from, $data['keyword']);

		$this->load->view('template/header', $data);
		$this->load->view('Admin/dashboard_admin', $data);
		$this->load->view('template/footer', $data);
	}

	public function outlet()
	{
		$data['judul_part'] = "Data Outlet | IOI Laundry";
		$data['page'] = $this->uri->segment(2);
		$data['status_page'] = "active";
		$data['total_paket'] = $this->paket_model->hitung_paket();
		$data['total_pelanggan'] = $this->pelanggan_model->hitung_pelanggan();
		$data['total_transaksi'] = $this->transaksi_model->hitung_transaksi();
		$data['total_outlet'] = $this->outlet_model->hitung_outlet();

		$this->load->database();

		// $jumlah_data = $this->outlet_model->jumlah_data();

		$this->load->library('pagination');

		if ($this->input->post('submit')) {
			$data['keyword'] = $this->input->post('keyword');
			$this->session->set_userdata('keyword', $data['keyword']);
		} else {
			$data['keyword'] = $this->session->userdata('keyword');
		}

		$config['base_url'] = base_url().'admin/outlet/';

		$this->db->like('nama_outlet', $data['keyword']);
		$this->db->or_like('alamat', $data['keyword']);
		$this->db->or_like('tlp', $data['keyword']);
		$this->db->from('outlet');

		$config['total_rows'] = $this->db->count_all_results();

		$config['per_page'] = 6;

		$config['attributes'] = array('class' => 'page-link');
		
		$from = $this->uri->segment(3);
		
		$this->pagination->initialize($config);

		$data['outlet'] = $this->outlet_model->data($config['per_page'], $from, $data['keyword']);

		$this->load->view('template/header', $data);
		$this->load->view('Admin/Outlet/outlet-view',$data);
		$this->load->view('template/footer', $data);
	}

	public function add_outlet_new()
	{
		$data['judul_part'] = "Tambah Outlet | IOI Laundry";
		$data['page'] = $this->uri->segment(2);
		$data['status_page'] = "active";
		$data['total_paket'] = $this->paket_model->hitung_paket();
		$data['total_pelanggan'] = $this->pelanggan_model->hitung_pelanggan();
		$data['total_transaksi'] = $this->transaksi_model->hitung_transaksi();
		$data['total_outlet'] = $this->outlet_model->hitung_outlet();

		$this->load->view('template/header', $data);
		$this->load->view('Admin/Outlet/add_new_outlet',$data);
		$this->load->view('template/footer', $data);
	}

	public function insert_outlet_new()
	{
		$nama_outlet = $this->input->post('nama_outlet');
		$alamat = $this->input->post('alamat');
		$tlp = $this->input->post('tlp');
		$this->outlet_model->tambah($nama_outlet,$alamat,$tlp);
		redirect('admin/outlet?alert=add_outlet');
	}

	public function edit_outlet()
	{
		$id_outlet = $this->uri->segment(3);
		$hasil = $this->outlet_model->get_id_outlet($id_outlet);
			if ($hasil->num_rows() > 0) {
				$i = $hasil->row_array();
				$data = array(
					'id_outlet' => $i['id_outlet'],
					'nama_outlet' => $i['nama_outlet'],
					'alamat' => $i['alamat'],
					'tlp' => $i['tlp']
				);

				$data['judul_part'] = "Edit Outlet | IOI Laundry";
				$data['page'] = $this->uri->segment(2);
				$data['status_page'] = "active";
				$data['total_paket'] = $this->paket_model->hitung_paket();
				$data['total_pelanggan'] = $this->pelanggan_model->hitung_pelanggan();
				$data['total_transaksi'] = $this->transaksi_model->hitung_transaksi();
				$data['total_outlet'] = $this->outlet_model->hitung_outlet();

				$this->load->view('template/header', $data);
				$this->load->view('Admin/Outlet/edit_outlet',$data);
				$this->load->view('template/footer', $data);
			} else {
				echo "Data tidak diketahui";
			}
	}

	public function update_outlet()
	{
		$id_outlet = $this->input->post('id_outlet');
		$nama_outlet = $this->input->post('nama_outlet');
		$alamat = $this->input->post('alamat');
		$tlp = $this->input->post('tlp');
		$this->outlet_model->updateoutlet($id_outlet,$nama_outlet,$alamat,$tlp);
		redirect('admin/outlet?alert=edit_outlet');
	}

	public function hapus_outlet()
	{
		$id_outlet = $this->uri->segment(3);
		$this->outlet_model->delete($id_outlet);
		redirect('admin/outlet?alert=del_outlet');
	}

	public function paket()
	{
		$data['judul_part'] = "Data Paket Cucian | IOI Laundry";
		$data['page'] = $this->uri->segment(2);
		$data['status_page'] = "active";
		$data['total_paket'] = $this->paket_model->hitung_paket();
		$data['total_pelanggan'] = $this->pelanggan_model->hitung_pelanggan();
		$data['total_transaksi'] = $this->transaksi_model->hitung_transaksi();
		$data['total_outlet'] = $this->outlet_model->hitung_outlet();

		$this->load->database();

		// $jumlah_data = $this->paket_model->jumlah_data();

		$this->load->library('pagination');

		if ($this->input->post('submit')) {
			$data['keyword'] = $this->input->post('keyword');
			$this->session->set_userdata('keyword', $data['keyword']);
		} else {
			$data['keyword'] = $this->session->userdata('keyword');
		}

		$config['base_url'] = base_url().'admin/paket/';

		$this->db->like('nama_paket', $data['keyword']);
		$this->db->or_like('jenis_paket', $data['keyword']);
		$this->db->or_like('harga_paket', $data['keyword']);
		$this->db->or_like('id_outlet', $data['keyword']);
		$this->db->from('paket_cucian');

		$config['total_rows'] = $this->db->count_all_results();

		$config['per_page'] = 6;

		$config['attributes'] = array('class' => 'page-link');
		
		$from = $this->uri->segment(3);
		
		$this->pagination->initialize($config);

		$data['paket'] = $this->paket_model->data($config['per_page'], $from, $data['keyword']);

		$this->load->view('template/header', $data);
		$this->load->view('Admin/Paket/paket-view',$data);
		$this->load->view('template/footer', $data);
	}

	public function add_paket_new()
	{
		$data['judul_part'] = "Tambah Paket Cucian | IOI Laundry";
		$data['page'] = $this->uri->segment(2);
		$data['status_page'] = "active";
		$data['outlet'] = $this->outlet_model->get_outlet();
		$data['total_paket'] = $this->paket_model->hitung_paket();
		$data['total_pelanggan'] = $this->pelanggan_model->hitung_pelanggan();
		$data['total_transaksi'] = $this->transaksi_model->hitung_transaksi();
		$data['total_outlet'] = $this->outlet_model->hitung_outlet();

		$this->load->view('template/header', $data);
		$this->load->view('Admin/Paket/add_new_paket',$data);
		$this->load->view('template/footer', $data);
	}

	public function insert_paket_new()
	{
		$id_outlet = $this->input->post('id_outlet');
		$nama_paket = $this->input->post('nama_paket');
		$jenis_paket = $this->input->post('jenis_paket');
		$harga_paket = $this->input->post('harga_paket');
		$this->paket_model->tambah($id_outlet,$nama_paket,$jenis_paket,$harga_paket);
		redirect('admin/paket?alert=add_paket');
	}

	public function edit_paket()
	{
		$id_paket = $this->uri->segment(3);
		$hasil = $this->paket_model->get_id_paket($id_paket);
			if ($hasil->num_rows() > 0) {
				$i = $hasil->row_array();
				$data = array(
					'id_paket' => $i['id_paket'],
					'id_outlet' => $i['id_outlet'],
					'nama_paket' => $i['nama_paket'],
					'jenis_paket' => $i['jenis_paket'],
					'harga_paket' => $i['harga_paket'],
				);

				$data['judul_part'] = "Edit Paket Cucian | IOI Laundry";
				$data['page'] = $this->uri->segment(2);
				$data['status_page'] = "active";
				$data['outlet'] = $this->outlet_model->get_outlet();
				$data['total_paket'] = $this->paket_model->hitung_paket();
				$data['total_pelanggan'] = $this->pelanggan_model->hitung_pelanggan();
				$data['total_transaksi'] = $this->transaksi_model->hitung_transaksi();
				$data['total_outlet'] = $this->outlet_model->hitung_outlet();

				$this->load->view('template/header', $data);
				$this->load->view('Admin/Paket/edit_paket',$data);
				$this->load->view('template/footer', $data);
			} else {
				echo "Data tidak diketahui";
			}
	}

	public function update_paket()
	{
		$id_paket = $this->input->post('id_paket');
		$id_outlet = $this->input->post('id_outlet');
		$nama_paket = $this->input->post('nama_paket');
		$jenis_paket = $this->input->post('jenis_paket');
		$harga_paket = $this->input->post('harga_paket');
		$this->paket_model->updatepaket($id_paket,$id_outlet,$nama_paket,$jenis_paket,$harga_paket);
		redirect('admin/paket?alert=edit_paket');
	}

	public function hapus_paket()
	{
		$id_paket = $this->uri->segment(3);
		$this->paket_model->delete($id_paket);
		redirect('admin/paket?alert=del_paket');
	}

	public function pengguna()
	{
		$data['judul_part'] = "Data Pengguna | IOI Laundry";
		$data['page'] = $this->uri->segment(2);
		$data['status_page'] = "active";
		$data['total_paket'] = $this->paket_model->hitung_paket();
		$data['total_pelanggan'] = $this->pelanggan_model->hitung_pelanggan();
		$data['total_transaksi'] = $this->transaksi_model->hitung_transaksi();
		$data['total_outlet'] = $this->outlet_model->hitung_outlet();

		$this->load->database();

		// $jumlah_data = $this->pengguna_model->jumlah_data();

		$this->load->library('pagination');

		if ($this->input->post('submit')) {
			$data['keyword'] = $this->input->post('keyword');
			$this->session->set_userdata('keyword', $data['keyword']);
		} else {
			$data['keyword'] = $this->session->userdata('keyword');
		}

		$config['base_url'] = base_url().'admin/pengguna/';

		$this->db->like('nama_user', $data['keyword']);
		$this->db->or_like('username', $data['keyword']);
		$this->db->or_like('id_outlet', $data['keyword']);
		$this->db->or_like('role', $data['keyword']);
		$this->db->from('user');

		$config['total_rows'] = $this->db->count_all_results();

		$config['per_page'] = 6;

		$config['attributes'] = array('class' => 'page-link');
		
		$from = $this->uri->segment(3);
		
		$this->pagination->initialize($config);

		$data['pengguna'] = $this->pengguna_model->data($config['per_page'], $from, $data['keyword']);

		$this->load->view('template/header', $data);
		$this->load->view('Admin/Pengguna/pengguna-view',$data);
		$this->load->view('template/footer', $data);
	}

	public function add_pengguna_new()
	{
		$data['judul_part'] = "Tambah Pengguna | IOI Laundry";
		$data['page'] = $this->uri->segment(2);
		$data['status_page'] = "active";
		$data['outlet'] = $this->outlet_model->get_outlet();
		$data['total_paket'] = $this->paket_model->hitung_paket();
		$data['total_pelanggan'] = $this->pelanggan_model->hitung_pelanggan();
		$data['total_transaksi'] = $this->transaksi_model->hitung_transaksi();
		$data['total_outlet'] = $this->outlet_model->hitung_outlet();

		$this->load->view('template/header', $data);
		$this->load->view('Admin/Pengguna/add_new_pengguna',$data);
		$this->load->view('template/footer', $data);
	}

	public function insert_pengguna_new()
	{
		$nama_user = $this->input->post('nama_user');
		$username = $this->input->post('username');
		$password = $this->input->post('password');
		$id_outlet = $this->input->post('id_outlet');
		$role = $this->input->post('role');
		$this->pengguna_model->tambah($nama_user,$username,md5($password),$id_outlet,$role);
		redirect('admin/pengguna?alert=add_pengguna');
	}

	public function edit_pengguna()
	{
		$id_user = $this->uri->segment(3);
		$hasil = $this->pengguna_model->get_id_user($id_user);
			if ($hasil->num_rows() > 0) {
				$i = $hasil->row_array();
				$data = array(
					'id_user' => $i['id_user'],
					'nama_user' => $i['nama_user'],
					'username' => $i['username'],
					'password' => $i['password'],
					'id_outlet' => $i['id_outlet'],
					'role' => $i['role']
				);

				$data['judul_part'] = "Edit Pengguna | IOI Laundry";
				$data['page'] = $this->uri->segment(2);
				$data['status_page'] = "active";
				$data['outlet'] = $this->outlet_model->get_outlet();
				$data['total_paket'] = $this->paket_model->hitung_paket();
				$data['total_pelanggan'] = $this->pelanggan_model->hitung_pelanggan();
				$data['total_transaksi'] = $this->transaksi_model->hitung_transaksi();
				$data['total_outlet'] = $this->outlet_model->hitung_outlet();

				$this->load->view('template/header', $data);
				$this->load->view('Admin/Pengguna/edit_pengguna',$data);
				$this->load->view('template/footer', $data);
			} else {
				echo "Data tidak diketahui";
			}
	}

	public function update_pengguna()
	{
		$id_user = $this->input->post('id_user');
		$nama_user = $this->input->post('nama_user');
		$username = $this->input->post('username');
		$password = $this->input->post('password');
		$id_outlet = $this->input->post('id_outlet');
		$role = $this->input->post('role');
		$this->pengguna_model->updatepengguna($id_user,$nama_user,$username,md5($password),$id_outlet,$role);
		redirect('admin/pengguna?alert=edit_pengguna');
	}

	public function hapus_pengguna()
	{
		$id_user = $this->uri->segment(3);
		$this->pengguna_model->delete($id_user);
		redirect('admin/pengguna?alert=del_pengguna');
	}

	public function pelanggan()
	{
		$data['judul_part'] = "Data Pelanggan | IOI Laundry";
		$data['page'] = $this->uri->segment(2);
		$data['status_page'] = "active";
		$data['total_paket'] = $this->paket_model->hitung_paket();
		$data['total_pelanggan'] = $this->pelanggan_model->hitung_pelanggan();
		$data['total_transaksi'] = $this->transaksi_model->hitung_transaksi();
		$data['total_outlet'] = $this->outlet_model->hitung_outlet();

		$this->load->database();

		// $jumlah_data = $this->pelanggan_model->jumlah_data();

		$this->load->library('pagination');

		if ($this->input->post('submit')) {
			$data['keyword'] = $this->input->post('keyword');
			$this->session->set_userdata('keyword', $data['keyword']);
		} else {
			$data['keyword'] = $this->session->userdata('keyword');
		}

		$config['base_url'] = base_url().'admin/pelanggan/';

		$this->db->like('nama_pelanggan', $data['keyword']);
		$this->db->or_like('alamat', $data['keyword']);
		$this->db->or_like('jenis_kelamin', $data['keyword']);
		$this->db->or_like('tlp', $data['keyword']);
		$this->db->from('pelanggan');

		$config['total_rows'] = $this->db->count_all_results();

		$config['per_page'] = 6;

		$config['attributes'] = array('class' => 'page-link');
		
		$from = $this->uri->segment(3);
		
		$this->pagination->initialize($config);

		$data['pelanggan'] = $this->pelanggan_model->data($config['per_page'], $from, $data['keyword']);

		$this->load->view('template/header', $data);
		$this->load->view('Admin/Pelanggan/pelanggan-view',$data);
		$this->load->view('template/footer', $data);
	}

	public function hapus_pelanggan()
	{
		$id_pelanggan = $this->uri->segment(3);
		$this->pelanggan_model->delete($id_pelanggan);
		redirect('admin/pelanggan?alert=del_pelanggan');
	}

	public function registrasi_pelanggan()
	{
		$data['judul_part'] = "Registrasi Pelanggan | IOI Laundry";
		$data['page'] = $this->uri->segment(2);
		$data['status_page'] = "active";
		$data['total_paket'] = $this->paket_model->hitung_paket();
		$data['total_pelanggan'] = $this->pelanggan_model->hitung_pelanggan();
		$data['total_transaksi'] = $this->transaksi_model->hitung_transaksi();
		$data['total_outlet'] = $this->outlet_model->hitung_outlet();

		$this->load->view('template/header', $data);
		$this->load->view('Admin/Pelanggan/registrasi_pelanggan',$data);
		$this->load->view('template/footer', $data);
	}

	public function proses_regist()
	{
		$this->form_validation->set_rules('nama_pelanggan', 'nama_pelanggan', 'required');
		$this->form_validation->set_rules('alamat', 'alamat', 'required');
		$this->form_validation->set_rules('jenis_kelamin', 'jenis_kelamin', 'required');
		$this->form_validation->set_rules('tlp', 'tlp', 'required');

		if ($this->form_validation->run() != false)
		{
			$nama_pelanggan = $this->input->post('nama_pelanggan');
			$alamat = $this->input->post('alamat');
			$jenis_kelamin = $this->input->post('jenis_kelamin');
			$tlp = $this->input->post('tlp');
			$this->regist_model->registerr($nama_pelanggan,$alamat,$jenis_kelamin,$tlp);
			redirect('admin/pelanggan?alert=regist_pelanggan');
		} 
		else
		{
			redirect('admin/registrasi_pelanggan');
		}
	}

	public function transaksi()
	{
		$data['judul_part'] = "Data Transaksi | IOI Laundry";
		$data['page'] = $this->uri->segment(2);
		$data['status_page'] = "active";
		$data['total_paket'] = $this->paket_model->hitung_paket();
		$data['total_pelanggan'] = $this->pelanggan_model->hitung_pelanggan();
		$data['total_transaksi'] = $this->transaksi_model->hitung_transaksi();
		$data['total_outlet'] = $this->outlet_model->hitung_outlet();

		$this->load->database();

		// $jumlah_data = $this->transaksi_model->jumlah_data();

		$this->load->library('pagination');

		if ($this->input->post('submit')) {
			$data['keyword'] = $this->input->post('keyword');
			$this->session->set_userdata('keyword', $data['keyword']);
		} else {
			$data['keyword'] = $this->session->userdata('keyword');
		}

		$config['base_url'] = base_url().'admin/transaksi/';

		$this->db->like('id_pelanggan', $data['keyword']);
		$this->db->or_like('tgl', $data['keyword']);
		$this->db->or_like('batas_waktu', $data['keyword']);
		$this->db->or_like('tgl_bayar', $data['keyword']);
		$this->db->like('status', $data['keyword']);
		$this->db->or_like('dibayar', $data['keyword']);
		$this->db->or_like('id_user', $data['keyword']);
		$this->db->from('transaksi');

		$config['total_rows'] = $this->db->count_all_results();

		$config['per_page'] = 5;

		$config['attributes'] = array('class' => 'page-link');
		
		$from = $this->uri->segment(3);
		
		$this->pagination->initialize($config);

		$data['transaksi'] = $this->transaksi_model->data($config['per_page'], $from, $data['keyword']);

		$this->load->view('template/header', $data);
		$this->load->view('Admin/Transaksi/transaksi-view',$data);
		$this->load->view('template/footer', $data);
	}

	public function add_transaksi_new()
	{
		$data['judul_part'] = "Tambah Entri Transaksi | IOI Laundry";
		$data['page'] = $this->uri->segment(2);
		$data['status_page'] = "active";
		$data['outlet'] = $this->outlet_model->get_outlet();
		$data['paket'] = $this->paket_model->get_paket();
		$data['pelanggan'] = $this->pelanggan_model->get_pelanggan();
		$data['pengguna'] = $this->pengguna_model->get_pengguna_role();
		$data['total_paket'] = $this->paket_model->hitung_paket();
		$data['total_pelanggan'] = $this->pelanggan_model->hitung_pelanggan();
		$data['total_transaksi'] = $this->transaksi_model->hitung_transaksi();
		$data['total_outlet'] = $this->outlet_model->hitung_outlet();

		$this->load->view('template/header', $data);
		$this->load->view('Admin/Transaksi/add_new_transaksi',$data);
		$this->load->view('template/footer', $data);
	}

	public function getharga()
	{
		$id_paket = $this->input->post('id_paket');
		$data = $this->transaksi_model->gethargapaket($id_paket);
		echo json_encode($data);
	}

	public function insert_transaksi_new()
	{
		$id_outlet = $this->input->post('id_outlet');
		$kode_invoice = $this->input->post('kode_invoice');
		$id_pelanggan = $this->input->post('id_pelanggan');
		$tgl = $this->input->post('tgl');
		$batas_waktu = $this->input->post('batas_waktu');
		$tgl_bayar = $this->input->post('tgl_bayar');
		$berat = $this->input->post('berat');
		$grand_total = $this->input->post('grand_total');
		// $jumlah_cucian = $this->input->post('jumlah_cucian');
		// $biaya_tambahan = $this->input->post('biaya_tambahan');
		// $diskon = $this->input->post('diskon');
		// $pajak = $this->input->post('pajak');
		$status = $this->input->post('status');
		$dibayar = $this->input->post('dibayar');
		$id_user = $this->input->post('id_user');
		$this->transaksi_model->tambah($id_outlet,$kode_invoice,$id_pelanggan,$tgl,$batas_waktu,$tgl_bayar,$berat,$grand_total,$status,$dibayar,$id_user);
		redirect('admin/transaksi?alert=add_transaksi');
	}

	public function detail_transaksi()
	{
		$id_transaksi = $this->uri->segment(3);
		$hasil = $this->transaksi_model->get_id_transaksi($id_transaksi);
			if ($hasil->num_rows() > 0) {
				$i = $hasil->row_array();
				$data = array(
					'id_transaksi' => $i['id_transaksi'],
					'id_outlet' => $i['id_outlet'],
					'kode_invoice' => $i['kode_invoice'],
					'id_pelanggan' => $i['id_pelanggan'],
					'tgl' => $i['tgl'],
					'batas_waktu' => $i['batas_waktu'],
					'tgl_bayar' => $i['tgl_bayar'],
					'berat' => $i['berat'],
					'grand_total' => $i['grand_total'],
					// 'jumlah_cucian' => $i['jumlah_cucian'],
					// 'biaya_tambahan' => $i['biaya_tambahan'],
					// 'diskon' => $i['diskon'],
					// 'pajak' => $i['pajak'],
					'status' => $i['status'],
					'dibayar' => $i['dibayar'],
					'id_user' => $i['id_user']
				);

				$data['judul_part'] = "Detail Transaksi | IOI Laundry";
				$data['page'] = $this->uri->segment(2);
				$data['status_page'] = "active";
				$data['outlet'] = $this->outlet_model->get_outlet();
				$data['paket'] = $this->paket_model->get_paket();
				$data['pelanggan'] = $this->pelanggan_model->get_pelanggan();
				$data['pengguna'] = $this->pengguna_model->get_pengguna_role();
				$data['total_paket'] = $this->paket_model->hitung_paket();
				$data['total_pelanggan'] = $this->pelanggan_model->hitung_pelanggan();
				$data['total_transaksi'] = $this->transaksi_model->hitung_transaksi();
				$data['total_outlet'] = $this->outlet_model->hitung_outlet();
				$data['join'] = $this->transaksi_model->join_transaksi_paket()->result();

				$this->load->view('template/header', $data);
				$this->load->view('Admin/Transaksi/detail_transaksi',$data);
				$this->load->view('template/footer', $data);
			} else {
				echo "Data tidak diketahui";
			}
	}

	public function update_transaksi()
	{
		$id_transaksi = $this->input->post('id_transaksi');
		$id_outlet = $this->input->post('id_outlet');
		$kode_invoice = $this->input->post('kode_invoice');
		$id_pelanggan = $this->input->post('id_pelanggan');
		$tgl = $this->input->post('tgl');
		$batas_waktu = $this->input->post('batas_waktu');
		$tgl_bayar = $this->input->post('tgl_bayar');
		$berat = $this->input->post('berat');
		$grand_total = $this->input->post('grand_total');
		// $jumlah_cucian = $this->input->post('jumlah_cucian');
		// $biaya_tambahan = $this->input->post('biaya_tambahan');
		// $diskon = $this->input->post('diskon');
		// $pajak = $this->input->post('pajak');
		$status = $this->input->post('status');
		$dibayar = $this->input->post('dibayar');
		$id_user = $this->input->post('id_user');
		$this->transaksi_model->updatetransaksi($id_transaksi,$id_outlet,$kode_invoice,$id_pelanggan,$tgl,$batas_waktu,$tgl_bayar,$berat,$grand_total,$status,$dibayar,$id_user);
		redirect('admin/transaksi');
	}

	public function laporan()
	{
		$data['judul_part'] = "Data Laporan | IOI Laundry";
		$data['page'] = $this->uri->segment(2);
		$data['status_page'] = "active";
		$data['laporan'] = $this->laporan_model->get_laporan();
		$data['total_paket'] = $this->paket_model->hitung_paket();
		$data['total_pelanggan'] = $this->pelanggan_model->hitung_pelanggan();
		$data['total_transaksi'] = $this->transaksi_model->hitung_transaksi();
		$data['total_outlet'] = $this->outlet_model->hitung_outlet();

		$this->load->view('template/header', $data);
		$this->load->view('Admin/Laporan/laporan-view',$data);
		$this->load->view('template/footer', $data);
	}

	public function pdfview_laporan()
	{
		$this->load->library('pdfgenerator');

		$data['title_pdf'] = 'Laporan IOI Laundry';

		$file_pdf = 'laporan-tes';

		$paper = 'A4';

		$orientation = 'portrait';

		$data['laporan'] = $this->laporan_model->get_laporan('laporan')->result();
		$html = $this->load->view('Admin/Laporan/laporan-tes',$data,true);

		$this->pdfgenerator->generate($html, $file_pdf, $paper, $orientation);
	}

	public function keluar() 
	{
		$this->session->sess_destroy();
		redirect('login_pengguna?alert=logout');
	}
}
?>