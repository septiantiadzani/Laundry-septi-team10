<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Kasir extends CI_Controller {
	function __construct()
	{
		parent::__construct();

		date_default_timezone_set('Asia/Jakarta');

		$this->load->helper(array('url'));

		$this->load->model('login_model','pelanggan_model','regist_model','transaksi_model','laporan_model');

		if ($this->session->userdata('status')!="telah_login_kasir") {
			redirect(base_url().'login_pengguna?alert=belum_login');
		}
	}

	public function index() 
	{
		$data['judul_part'] = "Dashboard Kasir | IOI Laundry";
		$data['page'] = $this->uri->segment(1);
		$data['status_page'] = "active";
		$data['total_paket'] = $this->paket_model->hitung_paket();
		$data['total_pelanggan'] = $this->pelanggan_model->hitung_pelanggan();
		$data['total_transaksi'] = $this->transaksi_model->hitung_transaksi();
		$data['total_outlet'] = $this->outlet_model->hitung_outlet();

		$this->load->database();

		// $jumlah_data = $this->transaksi_model->jumlah_data();

		$this->load->library('pagination');

		if ($this->input->post('submit')) {
			$data['keyword'] = $this->input->post('keyword');
			$this->session->set_userdata('keyword', $data['keyword']);
		} else {
			$data['keyword'] = $this->session->userdata('keyword');
		}

		$config['base_url'] = base_url().'kasir/index/';

		$this->db->like('id_pelanggan', $data['keyword']);
		$this->db->or_like('tgl', $data['keyword']);
		$this->db->or_like('batas_waktu', $data['keyword']);
		$this->db->or_like('tgl_bayar', $data['keyword']);
		$this->db->like('status', $data['keyword']);
		$this->db->or_like('dibayar', $data['keyword']);
		$this->db->or_like('id_user', $data['keyword']);
		$this->db->from('transaksi');

		$config['total_rows'] = $this->db->count_all_results();

		$config['per_page'] = 7;

		$config['attributes'] = array('class' => 'page-link');
		
		$from = $this->uri->segment(3);
		
		$this->pagination->initialize($config);

		$data['transaksi'] = $this->transaksi_model->data_transaksi_baru($config['per_page'], $from, $data['keyword']);

		$this->load->view('template/header2', $data);
		$this->load->view('Kasir/dashboard_kasir', $data);
		$this->load->view('template/footer', $data);
	}

	public function pelanggan()
	{
		$data['judul_part'] = "Data Pelanggan | IOI Laundry";
		$data['page'] = $this->uri->segment(2);
		$data['status_page'] = "active";
		$data['total_paket'] = $this->paket_model->hitung_paket();
		$data['total_pelanggan'] = $this->pelanggan_model->hitung_pelanggan();
		$data['total_transaksi'] = $this->transaksi_model->hitung_transaksi();
		$data['total_outlet'] = $this->outlet_model->hitung_outlet();

		$this->load->database();

		// $jumlah_data = $this->pelanggan_model->jumlah_data();

		$this->load->library('pagination');

		if ($this->input->post('submit')) {
			$data['keyword'] = $this->input->post('keyword');
			$this->session->set_userdata('keyword', $data['keyword']);
		} else {
			$data['keyword'] = $this->session->userdata('keyword');
		}

		$config['base_url'] = base_url().'kasir/pelanggan/';

		$this->db->like('nama_pelanggan', $data['keyword']);
		$this->db->or_like('alamat', $data['keyword']);
		$this->db->or_like('jenis_kelamin', $data['keyword']);
		$this->db->or_like('tlp', $data['keyword']);
		$this->db->from('pelanggan');

		$config['total_rows'] = $this->db->count_all_results();

		$config['per_page'] = 6;

		$config['attributes'] = array('class' => 'page-link');
		
		$from = $this->uri->segment(3);
		
		$this->pagination->initialize($config);

		$data['pelanggan'] = $this->pelanggan_model->data($config['per_page'], $from, $data['keyword']);

		$this->load->view('template/header2', $data);
		$this->load->view('Kasir/Pelanggan/pelanggan-view',$data);
		$this->load->view('template/footer', $data);
	}

	public function hapus_pelanggan()
	{
		$id_pelanggan = $this->uri->segment(3);
		$this->pelanggan_model->delete($id_pelanggan);
		redirect('kasir/pelanggan?alert=del_pelanggan');
	}

	public function registrasi_pelanggan()
	{
		$data['judul_part'] = "Registrasi Pelanggan | IOI Laundry";
		$data['page'] = $this->uri->segment(2);
		$data['status_page'] = "active";
		$data['total_paket'] = $this->paket_model->hitung_paket();
		$data['total_pelanggan'] = $this->pelanggan_model->hitung_pelanggan();
		$data['total_transaksi'] = $this->transaksi_model->hitung_transaksi();
		$data['total_outlet'] = $this->outlet_model->hitung_outlet();

		$this->load->view('template/header2', $data);
		$this->load->view('Kasir/Pelanggan/registrasi_pelanggan',$data);
		$this->load->view('template/footer', $data);
	}

	public function proses_regist()
	{
		$this->form_validation->set_rules('nama_pelanggan', 'nama_pelanggan', 'required');
		$this->form_validation->set_rules('alamat', 'alamat', 'required');
		$this->form_validation->set_rules('jenis_kelamin', 'jenis_kelamin', 'required');
		$this->form_validation->set_rules('tlp', 'tlp', 'required');

		if ($this->form_validation->run() != false)
		{
			$nama_pelanggan = $this->input->post('nama_pelanggan');
			$alamat = $this->input->post('alamat');
			$jenis_kelamin = $this->input->post('jenis_kelamin');
			$tlp = $this->input->post('tlp');
			$this->regist_model->registerr($nama_pelanggan,$alamat,$jenis_kelamin,$tlp);
			redirect('kasir/pelanggan?alert=regist_pelanggan');
		} 
		else
		{
			redirect('kasir/registrasi_pelanggan');
		}
	}

	public function keluar() 
	{
		$this->session->sess_destroy();
		redirect('login_pengguna?alert=logout');
	}
}
?>