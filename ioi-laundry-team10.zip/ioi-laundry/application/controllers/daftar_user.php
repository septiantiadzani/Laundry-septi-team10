<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Daftar_user extends CI_Controller {

	function __construct()
	{
		parent::__construct();
		$this->load->model('m_data');
	}

	public function index()
	{
		$this->load->view('registrasi_user');
	}

	public function proses_daftar()
	{
		$this->form_validation->set_rules('nama_user', 'nama_user', 'required');
		$this->form_validation->set_rules('username', 'username', 'required');
		$this->form_validation->set_rules('password', 'password', 'required');
		$this->form_validation->set_rules('id_outlet', 'id_outlet', 'required');
		$this->form_validation->set_rules('role', 'role', 'required');

		if ($this->form_validation->run()==true)
		{
			$nama_user = $this->input->post('nama_user');
			$username = $this->input->post('username');
			$password = $this->input->post('password');
			$id_outlet = $this->input->post('id_outlet');
			$role = $this->input->post('role');
			$this->m_data->daftar_user($nama_user,$username,$password,$id_outlet,$role);
			$this->session->set_flashdata('success_register','Proses pendaftaran berhasil');
			redirect('login');
		} 

		else
		{
			$this->session->set_flashdata('error_register', validation_errors());
			redirect('daftar_user');
		}
	}
}
?>