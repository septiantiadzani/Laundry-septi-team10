<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Login_pengguna extends CI_Controller {

	function __construct()
	{
		parent::__construct();
	}

	public function index()
	{
		$this->load->view('login_pengguna/form_login');
	}

	public function ceklogin()
	{
		$this->form_validation->set_rules('username', 'Username', 'required');
		$this->form_validation->set_rules('password', 'Password', 'required');

		if ($this->form_validation->run() != false) {
			
			$username = $this->input->post('username', true);
			$password = $this->input->post('password', true);

			$where = array(
				'username' => $username,
				'password' => md5($password)
			);

			$this->load->model('login_model');

			$cek = $this->login_model->cek_login('user',$where)->num_rows();

			if ($cek > 0) {
				$data =  $this->login_model->cek_login('user',$where)->row();
				$role = $data->role;
				if ($role == 'admin') {
					$data_session = array(
						'id_user' => $data->id_user,
						'nama_user' => $data->nama_user,
						'username' => $data->username,
						'role' => $data->role,
						'status' => 'telah_login_admin'
					);
					$this->session->set_userdata($data_session);
					redirect(base_url().'admin?alert=welcome_admin');
				} elseif ($role == 'kasir') {
					$data_session = array(
						'id_user' => $data->id_user,
						'nama_user' => $data->nama_user,
						'username' => $data->username,
						'role' => $data->role,
						'status' => 'telah_login_kasir'
					);
					$this->session->set_userdata($data_session);

					redirect(base_url().'kasir?alert=welcome_kasir');
				} elseif ($role == 'owner') {
					$data_session = array(
						'id_user' => $data->id_user,
						'nama_user' => $data->nama_user,
						'username' => $data->username,
						'role' => $data->role,
						'status' => 'telah_login_owner'
					);
					$this->session->set_userdata($data_session);

					redirect(base_url().'owner?alert=welcome_owner');
				}
			} else {
				redirect(base_url().'login_pengguna?alert=gagal');
			}
		} else {
			$this->load->view('login_pengguna/form_login');
		}
	}
}
?>