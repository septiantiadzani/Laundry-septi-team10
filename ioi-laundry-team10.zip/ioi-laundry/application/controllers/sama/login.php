<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Login extends CI_Controller {

	function __construct()
	{
		parent::__construct();
		$this->load->model('m_data');
	}

	public function index()
	{
		$this->load->view('form_login');
	}

	public function proses_login()
	{
		$username = $this->input->post('username');
		$password = $this->input->post('password');

		if ($this->m_data->login_user($username,$password))
		{
			redirect('dashboard_admin');
		}

		else
		{
			$this->session->set_flashdata('error_login', 'Username dan Password Salah');
			redirect('login');
		}
	}

	public function logout()
	{
		$this->session->unset_userdata('username');
		$this->session->unset_userdata('nama_user');
		$this->session->unset_userdata('is_login');
		redirect('login');
	}

	public function ceklogin()
	{
		$this->form_validation->set_rules('username', 'username', 'required');
		$this->form_validation->set_rules('password', 'password', 'required');

		if ($this->form_validation->run() != false) {
			
			$username = $this->input->post('username');
			$password = $this->input->post('password');

			$where = array('username' => $username, 'password' => md5($password));
			$this->load->model('m_data');

			$cek = $this->m_data->cek_login('user',$where)->num_rows();

			if ($cek > 0) {
				$data =  $this->m_data->cek_login('user',$where)->num_rows();
				$role = $data->role;
				if ($role == 'admin') {
					$data_session = array(
						'id_user' => $data->id_user,
						'nama_user' => $data->nama_user,
						'username' => $data->username,
						'role' => $data->role,
						'status' => 'telah_login'
					);
					$this->session->set_userdata($data_session);

					redirect(base_url().'admin');
				} elseif ($role == 'kasir') {
					$data_session = array(
						'id_user' => $data->id_user,
						'nama_user' => $data->nama_user,
						'username' => $data->username,
						'role' => $data->role,
						'status' => 'telah_login'
					);
					$this->session->set_userdata($data_session);

					redirect(base_url().'kasir');
				} elseif ($role == 'owner') {
					$data_session = array(
						'id_user' => $data->id_user,
						'nama_user' => $data->nama_user,
						'username' => $data->username,
						'role' => $data->role,
						'status' => 'telah_login'
					);
					$this->session->set_userdata($data_session);

					redirect(base_url().'owner');
				}
			} else {
				redirect(base_url().'login?alert=gagal');
			}
		} else {
			$this->load->view('login/form_login');
		}
	}
}
?>