<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Login2 extends CI_Controller {

	function __construct()
	{
		parent::__construct();
	}

	public function index()
	{
		$this->load->view('login/form_login');
	}

	public function ceklogin()
	{
		$this->form_validation->set_rules('username', 'Username', 'required');
		$this->form_validation->set_rules('password', 'Password', 'required');

		if ($this->form_validation->run() != false) {
			
			$username = $this->input->post('username');
			$password = $this->input->post('password');

			$where = array(
				'username' => $username,
				'password' => md5($password)
			);

			$this->load->model('m_data2');

			$cek = $this->m_data2->cek_login('user',$where)->num_rows();

			if ($cek > 0) {
				$data =  $this->m_data2->cek_login('user',$where)->row();
				$role = $data->role;
				if ($role == 'admin') {
					$data_session = array(
						'id_user' => $data->id_user,
						'nama_user' => $data->nama_user,
						'username' => $data->username,
						'role' => $data->role,
						'status' => 'telah_login'
					);
					$this->session->set_userdata($data_session);

					redirect(base_url().'admin');
				} elseif ($role == 'kasir') {
					$data_session = array(
						'id_user' => $data->id_user,
						'nama_user' => $data->nama_user,
						'username' => $data->username,
						'role' => $data->role,
						'status' => 'telah_login'
					);
					$this->session->set_userdata($data_session);

					redirect(base_url().'kasir');
				} elseif ($role == 'owner') {
					$data_session = array(
						'id_user' => $data->id_user,
						'nama_user' => $data->nama_user,
						'username' => $data->username,
						'role' => $data->role,
						'status' => 'telah_login'
					);
					$this->session->set_userdata($data_session);

					redirect(base_url().'owner');
				}
			} else {
				redirect(base_url().'login2?alert=gagal');
			}
		} else {
			$this->load->view('login/form_login');
		}
	}
}
?>