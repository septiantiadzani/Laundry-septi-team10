<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Transaksi extends CI_Controller {
	function __construct()
	{
		parent::__construct();
		$this->load->model('transaksi_model');	
	}

	function index()
	{
		$data['transaksi'] = $this->transaksi_model->get_transaksi();
		$this->load->view('transaksi-view',$data);
	}

	function add_new()
	{
		$this->load->view('add_new_outlet');
	}

	function insert()
	{
		$nama_outlet = $this->input->post('nama_outlet');
		$alamat = $this->input->post('alamat');
		$tlp = $this->input->post('tlp');
		$this->outlet_model->tambah($nama_outlet,$alamat,$tlp);
		redirect('outlet');
	}

	function edit()
	{
		$id_outlet = $this->uri->segment(3);
		$hasil = $this->outlet_model->get_id_outlet($id_outlet);
			if ($hasil->num_rows() > 0) {
				$i = $hasil->row_array();
				$data = array(
					'id_outlet' => $i['id_outlet'],
					'nama_outlet' => $i['nama_outlet'],
					'alamat' => $i['alamat'],
					'tlp' => $i['tlp']
				);
				$this->load->view('edit_outlet',$data);
			} else {
				echo "Data tidak diketahui";
			}
	}

	function update()
	{
		$id_outlet = $this->input->post('id_outlet');
		$nama_outlet = $this->input->post('nama_outlet');
		$alamat = $this->input->post('alamat');
		$tlp = $this->input->post('tlp');
		$this->outlet_model->update($id_outlet,$nama_outlet,$alamat,$tlp);
		redirect('outlet');
	}

	function delete()
	{
		$id_outlet = $this->uri->segment(3);
		$this->outlet_model->delete($id_outlet);
		redirect('outlet');
	}
}
?>