<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Paket extends CI_Controller {
	function __construct()
	{
		parent::__construct();
		$this->load->model('paket_model');	
	}

	function index()
	{
		$data['paket'] = $this->paket_model->get_paket();
		$this->load->view('paket-view',$data);
	}

	function add_new()
	{
		$this->load->view('add_new_paket');
	}

	function insert()
	{
		$id_outlet = $this->input->post('id_outlet');
		$nama_paket = $this->input->post('nama_paket');
		$jenis_paket = $this->input->post('jenis_paket');
		$harga_paket = $this->input->post('harga_paket');
		$this->paket_model->tambah($id_outlet,$nama_paket,$jenis_paket,$harga_paket);
		redirect('paket');
	}

	function edit()
	{
		$id_paket = $this->uri->segment(3);
		$hasil = $this->paket_model->get_id_paket($id_paket);
			if ($hasil->num_rows() > 0) {
				$i = $hasil->row_array();
				$data = array(
					'id_paket' => $i['id_paket'],
					'id_outlet' => $i['id_outlet'],
					'nama_paket' => $i['nama_paket'],
					'jenis_paket' => $i['jenis_paket'],
					'harga_paket' => $i['harga_paket'],
				);
				$this->load->view('edit_paket',$data);
			} else {
				echo "Data tidak diketahui";
			}
	}

	function update()
	{
		$id_paket = $this->input->post('id_paket');
		$id_outlet = $this->input->post('id_outlet');
		$nama_paket = $this->input->post('nama_paket');
		$jenis_paket = $this->input->post('jenis_paket');
		$harga_paket = $this->input->post('harga_paket');
		$this->paket_model->update($id_paket,$id_outlet,$nama_paket,$jenis_paket,$harga_paket);
		redirect('paket');
	}

	function delete()
	{
		$id_paket = $this->uri->segment(3);
		$this->paket_model->delete($id_paket);
		redirect('paket');
	}
}
?>