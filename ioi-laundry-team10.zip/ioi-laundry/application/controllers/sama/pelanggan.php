<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Pelanggan extends CI_Controller {
	function __construct()
	{
		parent::__construct();
		$this->load->model('pelanggan_model');	
	}

	function index()
	{
		$data['pelanggan'] = $this->pelanggan_model->get_pelanggan();
		$this->load->view('pelanggan-view',$data);
	}

	function add_new()
	{
		$this->load->view('add_new_pelanggan');
	}

	function insert()
	{
		$nama_pelanggan = $this->input->post('nama_pelanggan');
		$alamat = $this->input->post('alamat');
		$jenis_kelamin = $this->input->post('jenis_kelamin');
		$tlp = $this->input->post('tlp');
		$this->pelanggan_model->tambah($nama_pelanggan,$alamat,$jenis_kelamin,$tlp);
		redirect('pelanggan');
	}

	function edit()
	{
		$id_pelanggan = $this->uri->segment(3);
		$hasil = $this->pelanggan_model->get_id_pelanggan($id_pelanggan);
			if ($hasil->num_rows() > 0) {
				$i = $hasil->row_array();
				$data = array(
					'id_pelanggan' => $i['id_pelanggan'],
					'nama_pelanggan' => $i['nama_pelanggan'],
					'alamat' => $i['alamat'],
					'jenis_kelamin' => $i['jenis_kelamin'],
					'tlp' => $i['tlp']
				);
				$this->load->view('edit_pelanggan',$data);
			} else {
				echo "Data tidak diketahui";
			}
	}

	function update()
	{
		$id_pelanggan = $this->input->post('id_pelanggan');
		$nama_pelanggan = $this->input->post('nama_pelanggan');
		$alamat = $this->input->post('alamat');
		$jenis_kelamin = $this->input->post('jenis_kelamin');
		$tlp = $this->input->post('tlp');
		$this->pelanggan_model->update($id_pelanggan,$nama_pelanggan,$alamat,$jenis_kelamin,$tlp);
		redirect('pelanggan');
	}

	function delete()
	{
		$id_pelanggan = $this->uri->segment(3);
		$this->pelanggan_model->delete($id_pelanggan);
		redirect('pelanggan');
	}
}
?>