<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Pengguna extends CI_Controller {
	function __construct()
	{
		parent::__construct();
		$this->load->model('pengguna_model');	
	}

	function index()
	{
		$data['pengguna'] = $this->pengguna_model->get_pengguna();
		$this->load->view('pengguna-view',$data);
	}

	function add_new()
	{
		$this->load->view('add_new_pengguna');
	}

	function insert()
	{
		$nama_user = $this->input->post('nama_user');
		$username = $this->input->post('username');
		$password = $this->input->post('password');
		$id_outlet = $this->input->post('id_outlet');
		$role = $this->input->post('role');
		$this->pengguna_model->tambah($nama_user,$username,md5($password),$id_outlet,$role);
		redirect('pengguna');
	}

	function edit()
	{
		$id_user = $this->uri->segment(3);
		$hasil = $this->pengguna_model->get_id_user($id_user);
			if ($hasil->num_rows() > 0) {
				$i = $hasil->row_array();
				$data = array(
					'id_user' => $i['id_user'],
					'nama_user' => $i['nama_user'],
					'username' => $i['username'],
					'password' => $i['password'],
					'id_outlet' => $i['id_outlet'],
					'role' => $i['role']
				);
				$this->load->view('edit_pengguna',$data);
			} else {
				echo "Data tidak diketahui";
			}
	}

	function update()
	{
		$id_user = $this->input->post('id_user');
		$nama_user = $this->input->post('nama_user');
		$username = $this->input->post('username');
		$password = $this->input->post('password');
		$id_outlet = $this->input->post('id_outlet');
		$role = $this->input->post('role');
		$this->pengguna_model->update($id_user,$nama_user,$username,$password,$id_outlet,$role);
		redirect('pengguna');
	}

	function delete()
	{
		$id_user = $this->uri->segment(3);
		$this->pengguna_model->delete($id_user);
		redirect('pengguna');
	}
}
?>