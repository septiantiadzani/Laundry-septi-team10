<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Register extends CI_Controller {

	function __construct()
	{
		parent::__construct();
		$this->load->model('regist_model');
	}

	public function index()
	{
		$this->load->view('registrasi_pelanggan');
	}

	public function proses()
	{
		$this->form_validation->set_rules('nama_pelanggan', 'nama_pelanggan', 'required');
		$this->form_validation->set_rules('alamat', 'alamat', 'required');
		$this->form_validation->set_rules('jenis_kelamin', 'jenis_kelamin', 'required');
		$this->form_validation->set_rules('tlp', 'tlp', 'required');

		if ($this->form_validation->run()==true)
		{
			$nama_pelanggan = $this->input->post('nama_pelanggan');
			$alamat = $this->input->post('alamat');
			$jenis_kelamin = $this->input->post('jenis_kelamin');
			$tlp = $this->input->post('tlp');
			$this->regist_model->registerr($nama_pelanggan,$alamat,$jenis_kelamin,$tlp);
			$this->session->set_flashdata('success_register','Proses pendaftaran berhasil');
			redirect('pelanggan');
		} 

		else
		{
			$this->session->set_flashdata('error', validation_errors());
			redirect('register');
		}
	}
}
?>